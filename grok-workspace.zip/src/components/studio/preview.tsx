import { useCallback, useEffect, useRef } from "react";
import { ImagePlus } from "lucide-react";
import { drawFrame } from "@/lib/frame/draw";
import { useLoadedImage } from "@/hooks/use-loaded-image";
import { useFrameStore } from "@/store/frame-store";
import { cn } from "@/lib/utils";

export function FramePreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const config = useFrameStore((s) => s.config);
  const photoUrl = useFrameStore((s) => s.photoUrl);
  const textureUrl = useFrameStore((s) => s.textureUrl);
  const includePhoto = useFrameStore((s) => s.includePhoto);
  const setPhotoUrl = useFrameStore((s) => s.setPhotoUrl);
  const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
  const photo = useLoadedImage(photoUrl);
  const texture = useLoadedImage(textureUrl);

  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const maxW = Math.max(80, wrap.clientWidth - 20);
    const maxH = Math.max(80, wrap.clientHeight - 20);
    const scale = Math.min(1, maxW / config.width, maxH / config.height);
    const dw = Math.max(1, Math.round(config.width * scale));
    const dh = Math.max(1, Math.round(config.height * scale));
    const dpr = Math.min(2, window.devicePixelRatio || 1);

    canvas.width = Math.round(dw * dpr);
    canvas.height = Math.round(dh * dpr);
    canvas.style.width = `${dw}px`;
    canvas.style.height = `${dh}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.scale(dw / config.width, dh / config.height);
    drawFrame(ctx, config, {
      photo,
      textureImg: texture,
      includePhoto: includePhoto && Boolean(photo),
    });
  }, [config, photo, texture, includePhoto]);

  useEffect(() => {
    redraw();
  }, [redraw]);

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const ro = new ResizeObserver(() => redraw());
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [redraw]);

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (!file || !file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    setPhotoUrl(url);
    setIncludePhoto(true);
  }

  return (
    <div
      ref={wrapRef}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
      className={cn(
        "bg-checker relative flex min-h-52 flex-1 items-center justify-center overflow-hidden rounded-lg",
        "min-h-[220px] md:min-h-[420px]",
      )}
    >
      <canvas
        ref={canvasRef}
        className="max-h-full max-w-full shadow-[0_12px_40px_rgb(0_0_0_/0.45)]"
        aria-label="Vista previa del marco"
      />
      {!photoUrl && (
        <p className="pointer-events-none absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-background/80 px-3 py-1 text-[11px] text-muted-foreground backdrop-blur-sm">
          <ImagePlus className="size-3" />
          Suelta una foto para probar el marco
        </p>
      )}
    </div>
  );
}
