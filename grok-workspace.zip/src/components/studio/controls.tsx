import { useRef } from "react";
import {
  Circle,
  ImagePlus,
  RectangleHorizontal,
  RotateCcw,
  Square,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { ASPECT_PRESETS } from "@/lib/frame/presets";
import { MAX_SIZE, MIN_SIZE, ORNAMENTS, PALETTE } from "@/lib/frame/types";
import type { DecoType, FrameShape, TextureKind } from "@/lib/frame/types";
import { cn } from "@/lib/utils";
import { useFrameStore } from "@/store/frame-store";
import { PresetStrip } from "./preset-strip";

const SHAPES: { id: FrameShape; label: string }[] = [
  { id: "rect", label: "Rectángulo" },
  { id: "rounded", label: "Redondeado" },
  { id: "circle", label: "Círculo" },
  { id: "oval", label: "Óvalo" },
  { id: "arch", label: "Arco" },
];

const DECO_TYPES: { id: DecoType; label: string }[] = [
  { id: "none", label: "Ninguno" },
  { id: "icons", label: "Motivos" },
  { id: "text", label: "Texto" },
  { id: "both", label: "Motivos y texto" },
  { id: "texture", label: "Textura" },
  { id: "image", label: "Imagen propia" },
];

const TEXTURES: { id: TextureKind; label: string }[] = [
  { id: "oro", label: "Hoja de oro" },
  { id: "metal", label: "Metal" },
  { id: "barroco", label: "Barroco" },
  { id: "puntos", label: "Puntos" },
  { id: "lineas", label: "Líneas" },
  { id: "cuadros", label: "Cuadros" },
  { id: "ondas", label: "Ondas" },
  { id: "floral", label: "Floral" },
  { id: "madera", label: "Madera" },
  { id: "damasco", label: "Damasco" },
];

const BAND_LABELS = ["Exterior", "Media", "Interior"] as const;

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-3">
      <h2 className="font-display text-base font-medium tracking-tight text-foreground">{title}</h2>
      {children}
    </section>
  );
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-2">{children}</div>;
}

function Field({ label, value, children }: { label: string; value?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between gap-2">
        <Label>{label}</Label>
        {value ? <span className="font-sans text-[11px] tabular-nums text-muted-foreground">{value}</span> : null}
      </div>
      {children}
    </div>
  );
}

export function Controls() {
  const config = useFrameStore((s) => s.config);
  const patch = useFrameStore((s) => s.patch);
  const setBand = useFrameStore((s) => s.setBand);
  const setRatio = useFrameStore((s) => s.setRatio);
  const toggleIcon = useFrameStore((s) => s.toggleIcon);
  const setDecoType = useFrameStore((s) => s.setDecoType);
  const setTexture = useFrameStore((s) => s.setTexture);
  const setShape = useFrameStore((s) => s.setShape);
  const activeBand = useFrameStore((s) => s.activeBand);
  const setActiveBand = useFrameStore((s) => s.setActiveBand);
  const setPhotoUrl = useFrameStore((s) => s.setPhotoUrl);
  const setTextureUrl = useFrameStore((s) => s.setTextureUrl);
  const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
  const includePhoto = useFrameStore((s) => s.includePhoto);
  const photoUrl = useFrameStore((s) => s.photoUrl);
  const fileName = useFrameStore((s) => s.fileName);
  const setFileName = useFrameStore((s) => s.setFileName);
  const clearDecor = useFrameStore((s) => s.clearDecor);
  const resetAll = useFrameStore((s) => s.resetAll);
  const photoInput = useRef<HTMLInputElement>(null);
  const textureInput = useRef<HTMLInputElement>(null);

  const showIcons = config.decoType === "icons" || config.decoType === "both";
  const showText = config.decoType === "text" || config.decoType === "both";
  const showTexture = config.decoType === "texture";
  const showImage = config.decoType === "image";
  const showDecoStyle = config.decoType !== "none";

  function onPhoto(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setPhotoUrl(URL.createObjectURL(file));
    setIncludePhoto(true);
  }

  function onTextureFile(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setTextureUrl(URL.createObjectURL(file));
  }

  return (
    <div className="flex flex-col gap-6 pb-4">
      <Section title="Estilos">
        <PresetStrip />
      </Section>

      <Separator />

      <Section title="Tamaño y forma">
        <div className="flex gap-1.5 overflow-x-auto pb-0.5">
          {ASPECT_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => patch({ width: p.width, height: p.height })}
              className={cn(
                "h-11 shrink-0 rounded-md px-3 text-xs font-medium transition-colors duration-[var(--motion-quick)]",
                config.width === p.width && config.height === p.height
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-accent",
              )}
            >
              {p.label}
              <span className="ml-1.5 text-[10px] opacity-70">{p.ratio}</span>
            </button>
          ))}
        </div>
        <Row>
          <Field label="Ancho">
            <Input
              type="number"
              min={MIN_SIZE}
              max={MAX_SIZE}
              value={config.width}
              onChange={(e) =>
                patch({ width: Math.min(MAX_SIZE, Math.max(MIN_SIZE, Number(e.target.value) || MIN_SIZE)) })
              }
            />
          </Field>
          <Field label="Alto">
            <Input
              type="number"
              min={MIN_SIZE}
              max={MAX_SIZE}
              value={config.height}
              onChange={(e) =>
                patch({ height: Math.min(MAX_SIZE, Math.max(MIN_SIZE, Number(e.target.value) || MIN_SIZE)) })
              }
            />
          </Field>
        </Row>
        <div className="grid grid-cols-3 gap-1.5">
          {SHAPES.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setShape(s.id)}
              className={cn(
                "flex h-14 flex-col items-center justify-center gap-1 rounded-md px-1 text-center text-xs font-medium leading-tight transition-colors duration-[var(--motion-quick)]",
                config.shape === s.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:bg-accent hover:text-foreground",
              )}
            >
              {s.id === "circle" ? (
                <Circle className="size-4" />
              ) : s.id === "rect" ? (
                <Square className="size-4" />
              ) : (
                <RectangleHorizontal className="size-4" />
              )}
              {s.label}
            </button>
          ))}
        </div>
        <Field label="Grosor" value={`${config.thickness} px`}>
          <Slider
            min={25}
            max={160}
            step={1}
            value={[config.thickness]}
            onValueChange={(v) => patch({ thickness: v[0] ?? config.thickness })}
          />
        </Field>
        {config.shape === "rounded" && (
          <Field label="Esquinas" value={`${config.cornerRadius} px`}>
            <Slider
              min={4}
              max={120}
              step={1}
              value={[config.cornerRadius]}
              onValueChange={(v) => patch({ cornerRadius: v[0] ?? config.cornerRadius })}
            />
          </Field>
        )}
      </Section>

      <Separator />

      <Section title="Bandas">
        <p className="text-xs text-muted-foreground">
          Tres capas: exterior, media e interior. Pulsa una para pintar con la paleta.
        </p>
        <div className="flex h-10 overflow-hidden rounded-md shadow-[var(--shadow-border)]">
          {config.bands.map((color, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActiveBand(i as 0 | 1 | 2)}
              style={{ width: `${config.ratios[i] * 100}%`, background: color }}
              className={cn(
                "relative h-full min-w-8 transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
                activeBand === i && "ring-2 ring-ring ring-inset",
              )}
              aria-label={BAND_LABELS[i]}
            />
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2">
          {config.bands.map((color, i) => (
            <Field key={i} label={BAND_LABELS[i]}>
              <label className="relative block">
                <span
                  className={cn(
                    "block h-11 w-full rounded-md shadow-[var(--shadow-border)]",
                    activeBand === i && "ring-2 ring-ring",
                  )}
                  style={{ background: color }}
                />
                <input
                  type="color"
                  value={color}
                  onChange={(e) => {
                    setActiveBand(i as 0 | 1 | 2);
                    setBand(i as 0 | 1 | 2, e.target.value);
                  }}
                  onClick={() => setActiveBand(i as 0 | 1 | 2)}
                  className="absolute inset-0 cursor-pointer opacity-0"
                  aria-label={`Color ${BAND_LABELS[i]}`}
                />
              </label>
            </Field>
          ))}
        </div>
        <Field
          label={`Proporción ${BAND_LABELS[activeBand].toLowerCase()}`}
          value={`${Math.round(config.ratios[activeBand] * 100)}%`}
        >
          <Slider
            min={0.1}
            max={0.7}
            step={0.01}
            value={[config.ratios[activeBand]]}
            onValueChange={(v) => setRatio(activeBand, v[0] ?? config.ratios[activeBand])}
          />
        </Field>
        <div>
          <Label className="mb-2 block">Paleta</Label>
          <div className="grid grid-cols-8 gap-1">
            {PALETTE.map((col) => (
              <button
                key={col}
                type="button"
                onClick={() => setBand(activeBand, col)}
                className={cn(
                  "aspect-square rounded-sm shadow-[var(--shadow-border)]",
                  config.bands[activeBand].toLowerCase() === col && "ring-2 ring-ring",
                )}
                style={{ background: col }}
                aria-label={col}
              />
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-3">
          <label className="flex h-11 items-center justify-between gap-3">
            <span className="text-sm text-foreground">Relieve</span>
            <Switch checked={config.bevel} onCheckedChange={(v) => patch({ bevel: v })} />
          </label>
          <label className="flex h-11 items-center justify-between gap-3">
            <span className="text-sm text-foreground">Filete interior</span>
            <Switch checked={config.innerLine} onCheckedChange={(v) => patch({ innerLine: v })} />
          </label>
        </div>
      </Section>

      <Separator />

      <Section title="Adornos">
        <Field label="Tipo">
          <Select value={config.decoType} onValueChange={(v) => setDecoType(v as DecoType)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DECO_TYPES.map((d) => (
                <SelectItem key={d.id} value={d.id}>
                  {d.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>

        {showIcons && (
          <div>
            <Label className="mb-2 block">Motivos (varios a la vez)</Label>
            <div className="grid max-h-32 grid-cols-8 gap-1 overflow-y-auto pr-1">
              {ORNAMENTS.map((ico) => {
                const on = config.icons.includes(ico);
                return (
                  <button
                    key={ico}
                    type="button"
                    onClick={() => toggleIcon(ico)}
                    className={cn(
                      "flex size-9 items-center justify-center rounded-sm text-base transition-colors duration-[var(--motion-quick)]",
                      on
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-foreground hover:bg-accent",
                    )}
                    aria-pressed={on}
                    aria-label={`Motivo ${ico}`}
                  >
                    {ico}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {showText && (
          <Field label="Texto en el contorno">
            <Input
              maxLength={18}
              value={config.text}
              onChange={(e) => patch({ text: e.target.value })}
              placeholder="tu texto"
            />
          </Field>
        )}

        {showTexture && (
          <Field label="Plantilla">
            <Select value={config.texture} onValueChange={(v) => setTexture(v as TextureKind)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TEXTURES.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        )}

        {showImage && (
          <div className="flex flex-col gap-2">
            <input
              ref={textureInput}
              type="file"
              accept="image/*"
              className="sr-only"
              tabIndex={-1}
              aria-hidden
              onChange={(e) => onTextureFile(e.target.files)}
            />
            <Button type="button" variant="secondary" onClick={() => textureInput.current?.click()}>
              <ImagePlus className="size-4" />
              Subir textura
            </Button>
          </div>
        )}

        {showDecoStyle && (
          <>
            <Row>
              <Field label="Color">
                <label className="relative block">
                  <span
                    className="block h-11 w-full rounded-md shadow-[var(--shadow-border)]"
                    style={{ background: config.decoColor }}
                  />
                  <input
                    type="color"
                    value={config.decoColor}
                    onChange={(e) => patch({ decoColor: e.target.value })}
                    className="absolute inset-0 cursor-pointer opacity-0"
                  />
                </label>
              </Field>
              <Field label="Tamaño" value={`${config.decoSize}`}>
                <Slider
                  min={10}
                  max={52}
                  step={1}
                  value={[config.decoSize]}
                  onValueChange={(v) => patch({ decoSize: v[0] ?? config.decoSize })}
                />
              </Field>
            </Row>
            <Field label="Cantidad en el contorno" value={`${config.decoCount}`}>
              <Slider
                min={6}
                max={64}
                step={1}
                value={[config.decoCount]}
                onValueChange={(v) => patch({ decoCount: v[0] ?? config.decoCount })}
              />
            </Field>
          </>
        )}
      </Section>

      <Separator />

      <Section title="Foto">
        <input
          ref={photoInput}
          type="file"
          accept="image/*"
          className="sr-only"
          tabIndex={-1}
          aria-hidden
          onChange={(e) => onPhoto(e.target.files)}
        />
        <Button type="button" variant="secondary" onClick={() => photoInput.current?.click()}>
          <ImagePlus className="size-4" />
          {photoUrl ? "Cambiar foto" : "Colocar foto"}
        </Button>
        {photoUrl && (
          <label className="flex h-11 items-center justify-between gap-3">
            <span className="text-sm text-foreground">Ver foto en el hueco</span>
            <Switch checked={includePhoto} onCheckedChange={setIncludePhoto} />
          </label>
        )}
        <p className="text-xs text-muted-foreground">
          El PNG por defecto deja el centro transparente. Activa “incluir foto” al exportar si quieres el retrato
          dentro.
        </p>
      </Section>

      <Separator />

      <Section title="Archivo">
        <Field label="Nombre del PNG">
          <Input value={fileName} onChange={(e) => setFileName(e.target.value)} />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Button type="button" variant="outline" onClick={clearDecor}>
            <Trash2 className="size-4" />
            Limpiar adornos
          </Button>
          <Button type="button" variant="outline" onClick={resetAll}>
            <RotateCcw className="size-4" />
            Restablecer
          </Button>
        </div>
      </Section>
    </div>
  );
}
