import { useEffect, useState } from "react";
import { Download, Share, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    ("standalone" in window.navigator && Boolean((window.navigator as { standalone?: boolean }).standalone))
  );
}

function isIos() {
  if (typeof navigator === "undefined") return false;
  return /iphone|ipad|ipod/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

export function InstallApp({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [ios, setIos] = useState(false);
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [busyHtml, setBusyHtml] = useState(false);

  useEffect(() => {
    setInstalled(isStandalone());
    setIos(isIos());
    const onBip = (event: Event) => {
      event.preventDefault();
      setDeferred(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
      toast.success("App instalada en este dispositivo");
    };
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBip);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  async function installNative() {
    if (!deferred) return;
    await deferred.prompt();
    const choice = await deferred.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setDeferred(null);
    setOpen(false);
  }

  function openIosGuide() {
    window.location.assign("/?install=1&platform=ios");
  }

  async function downloadStandaloneHtml() {
    setBusyHtml(true);
    try {
      const res = await fetch("/creador-de-marcos.html");
      if (!res.ok) throw new Error("missing");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "creador-de-marcos.html";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success("HTML descargado. Ábrelo en el navegador del móvil.");
      setOpen(false);
    } catch {
      toast.error("No se pudo descargar el HTML");
    } finally {
      setBusyHtml(false);
    }
  }

  if (installed) return null;

  return (
    <>
      <Button
        type="button"
        variant={compact ? "outline" : "secondary"}
        size={compact ? "icon" : "sm"}
        onClick={() => setOpen(true)}
        aria-label="Instalar en el móvil"
      >
        <Smartphone className="size-4" />
        {compact ? null : "Instalar"}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Llevar al móvil</DialogTitle>
            <DialogDescription>
              Queda como app en la pantalla de inicio, o descarga un HTML con todas las funciones.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-2">
            {deferred ? (
              <Button type="button" onClick={installNative}>
                <Smartphone className="size-4" />
                Instalar ahora
              </Button>
            ) : ios ? (
              <Button type="button" onClick={openIosGuide}>
                <Share className="size-4" />
                Guía para iPhone
              </Button>
            ) : (
              <p className="rounded-lg bg-secondary px-3 py-3 text-sm leading-relaxed text-secondary-foreground">
                En Chrome o Edge, abre el menú y elige <strong>Instalar aplicación</strong> o{" "}
                <strong>Añadir a la pantalla de inicio</strong>.
              </p>
            )}

            <Button type="button" variant="outline" onClick={downloadStandaloneHtml} disabled={busyHtml}>
              <Download className="size-4" />
              Descargar HTML completo
            </Button>
          </div>

          <ol className="list-decimal space-y-1.5 pl-4 text-xs leading-relaxed text-muted-foreground">
            <li>Abre esta página en el navegador del teléfono (Safari o Chrome), no dentro de otra app.</li>
            <li>Instálala para usarla a pantalla completa, sin barra de direcciones.</li>
            <li>El HTML descargado funciona sin conexión: gárdalo y ábrelo cuando quieras.</li>
          </ol>
        </DialogContent>
      </Dialog>
    </>
  );
}
