import { useEffect, useRef } from "react";
import { drawFrame } from "@/lib/frame/draw";
import { FRAME_PRESETS, applyPreset } from "@/lib/frame/presets";
import { DEFAULT_CONFIG } from "@/lib/frame/types";
import { useFrameStore } from "@/store/frame-store";
import { cn } from "@/lib/utils";

function Thumb({ presetId }: { presetId: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const preset = FRAME_PRESETS.find((p) => p.id === presetId);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || !preset) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = 120;
    const h = 88;
    canvas.width = w * 2;
    canvas.height = h * 2;
    ctx.scale(2, 2);
    const config = applyPreset(DEFAULT_CONFIG, preset);
    drawFrame(ctx, {
      ...config,
      width: w,
      height: h,
      thickness: 16,
      decoSize: 7,
      decoCount: 10,
      cornerRadius: Math.min(12, config.cornerRadius),
    });
  }, [preset]);

  return <canvas ref={ref} className="h-[66px] w-[90px]" />;
}

export function PresetStrip() {
  const apply = useFrameStore((s) => s.applyPreset);
  const current = useFrameStore((s) => s.config);

  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {FRAME_PRESETS.map((preset) => {
        const active =
          current.bands[0] === preset.config.bands?.[0] &&
          current.shape === (preset.config.shape ?? current.shape);
        return (
          <button
            key={preset.id}
            type="button"
            onClick={() => apply(preset)}
            className={cn(
              "flex shrink-0 flex-col gap-1.5 rounded-lg p-1.5 text-left transition-colors duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              active ? "bg-accent" : "hover:bg-accent/60",
            )}
          >
            <span className="overflow-hidden rounded-md bg-checker shadow-[var(--shadow-border)]">
              <Thumb presetId={preset.id} />
            </span>
            <span className="px-0.5">
              <span className="block text-xs font-medium text-foreground">{preset.name}</span>
              <span className="block text-[10px] text-muted-foreground">{preset.hint}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
