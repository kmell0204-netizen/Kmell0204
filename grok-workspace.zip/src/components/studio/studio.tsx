import { useEffect, useRef, useState } from "react";
import { Copy, Download, FolderOpen, Frame, Save, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { copyPng, downloadPng, pickDirectory } from "@/lib/frame/export";
import { useLoadedImage } from "@/hooks/use-loaded-image";
import { cn } from "@/lib/utils";
import { useFrameStore } from "@/store/frame-store";
import { InstallApp } from "./install-app";
import { Controls } from "./controls";
import { FramePreview } from "./preview";

export function Studio() {
  const hydrate = useFrameStore((s) => s.hydrate);
  const config = useFrameStore((s) => s.config);
  const fileName = useFrameStore((s) => s.fileName);
  const includePhoto = useFrameStore((s) => s.includePhoto);
  const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
  const photoUrl = useFrameStore((s) => s.photoUrl);
  const textureUrl = useFrameStore((s) => s.textureUrl);
  const saved = useFrameStore((s) => s.saved);
  const saveStyle = useFrameStore((s) => s.saveStyle);
  const loadStyle = useFrameStore((s) => s.loadStyle);
  const deleteStyle = useFrameStore((s) => s.deleteStyle);
  const photo = useLoadedImage(photoUrl);
  const texture = useLoadedImage(textureUrl);
  const dirRef = useRef<FileSystemDirectoryHandle | null>(null);
  const [styleName, setStyleName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const extras = {
    photo,
    textureImg: texture,
    includePhoto: includePhoto && Boolean(photo),
  };

  async function onDownload() {
    setBusy(true);
    try {
      const result = await downloadPng(config, extras, fileName, dirRef.current);
      toast.success(
        result.method === "folder"
          ? `Guardado en la carpeta: ${result.name}`
          : `Descargado: ${result.name}`,
      );
    } catch (err) {
      console.error(err);
      toast.error("No se pudo guardar el PNG");
    } finally {
      setBusy(false);
    }
  }

  async function onCopy() {
    try {
      await copyPng(config, extras);
      toast.success("PNG copiado al portapapeles");
    } catch {
      toast.error("Este navegador no permite copiar la imagen");
    }
  }

  async function onFolder() {
    try {
      dirRef.current = await pickDirectory();
      toast.success("Carpeta lista. El PNG se guardará ahí.");
    } catch (err) {
      if (err instanceof Error && err.message === "unsupported") {
        toast.error("Elegir carpeta solo funciona en Chrome o Edge");
        return;
      }
    }
  }

  function onSaveStyle() {
    saveStyle(styleName);
    setStyleName("");
    toast.success("Estilo guardado en este dispositivo");
  }

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <header className="border-b border-border px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 md:px-6">
        <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-lg bg-secondary text-foreground">
              <Frame className="size-5" />
            </span>
            <div className="min-w-0">
              <p className="text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase">
                Atelier
              </p>
              <h1 className="font-display text-xl leading-tight font-semibold tracking-tight md:text-2xl">
                Creador de Marcos
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="md:hidden">
              <InstallApp compact />
            </span>
            <div className="hidden items-center gap-2 md:flex">
              <InstallApp />
              <Button variant="outline" size="sm" onClick={onFolder}>
                <FolderOpen className="size-4" />
                Carpeta
              </Button>
              <Button variant="secondary" size="sm" onClick={onCopy}>
                <Copy className="size-4" />
                Copiar
              </Button>
              <Button size="sm" onClick={onDownload} disabled={busy}>
                <Download className="size-4" />
                Guardar PNG
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-[1200px] flex-1 flex-col gap-4 p-4 md:grid md:grid-cols-[360px_minmax(0,1fr)] md:gap-6 md:p-6">
        <aside className="order-2 min-h-0 pb-24 md:order-1 md:h-[calc(100dvh-8.5rem)] md:overflow-y-auto md:pb-0">
          <div className="rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5">
            <Controls />

              <div className="mt-2 flex flex-col gap-3">
                <h2 className="font-display text-base font-medium tracking-tight">Estilos guardados</h2>
                <div className="flex gap-2">
                  <Input
                    placeholder="Nombre del estilo"
                    value={styleName}
                    onChange={(e) => setStyleName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") onSaveStyle();
                    }}
                  />
                  <Button type="button" variant="secondary" onClick={onSaveStyle} className="shrink-0 px-3">
                    <Save className="size-4" />
                    Guardar
                  </Button>
                </div>
                {saved.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    Los estilos quedan en este dispositivo. No se envían a ningún servidor.
                  </p>
                ) : (
                  <ul className="flex flex-col gap-1">
                    {saved.map((s) => (
                      <li
                        key={s.id}
                        className="flex items-center gap-2 rounded-md bg-secondary px-2 py-1.5"
                      >
                        <button
                          type="button"
                          onClick={() => loadStyle(s.id)}
                          className="min-w-0 flex-1 truncate text-left text-sm hover:text-primary"
                        >
                          {s.name}
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteStyle(s.id)}
                          className="flex size-9 items-center justify-center rounded-sm text-muted-foreground hover:bg-accent hover:text-foreground"
                          aria-label={`Eliminar ${s.name}`}
                        >
                          <X className="size-3.5" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
            <p className="px-1 pt-4 pb-20 text-xs leading-relaxed text-muted-foreground md:pb-4">
              Centro transparente por defecto. Inspirado en el original de kmell@hotmail.com.
            </p>
        </aside>

        <section className="order-1 flex min-h-0 flex-col gap-3 md:order-2 md:sticky md:top-6 md:h-[calc(100dvh-8.5rem)]">
          <div
            className={cn(
              "flex min-h-0 flex-1 flex-col rounded-2xl bg-card p-3 shadow-[var(--shadow-border)] md:p-4",
            )}
          >
            <div className="mb-3 flex items-center justify-between gap-3 px-1">
              <h2 className="font-display text-base font-medium tracking-tight">Vista previa</h2>
              <span className="text-[11px] tabular-nums text-muted-foreground">
                {config.width} × {config.height}
              </span>
            </div>
            <FramePreview />
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 px-1">
              <label className="flex h-11 items-center gap-3 text-sm">
                <Switch
                  checked={includePhoto}
                  onCheckedChange={setIncludePhoto}
                  disabled={!photoUrl}
                />
                Incluir foto en el PNG
              </label>
              <p className="text-[11px] text-muted-foreground">Hueco transparente si está apagado</p>
            </div>
          </div>
        </section>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-sm md:hidden">
        <div className="flex gap-2">
          <Button variant="secondary" className="flex-1" onClick={onCopy}>
            <Copy className="size-4" />
            Copiar
          </Button>
          <Button className="flex-[2]" onClick={onDownload} disabled={busy}>
            <Download className="size-4" />
            Guardar PNG
          </Button>
        </div>
      </div>
    </div>
  );
}
