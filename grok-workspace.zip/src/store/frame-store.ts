import { create } from "zustand";
import type { DecoType, FrameConfig, FrameShape, SavedStyle, TextureKind } from "@/lib/frame/types";
import { DEFAULT_CONFIG } from "@/lib/frame/types";
import { applyPreset, type FramePreset } from "@/lib/frame/presets";
import { loadPersisted, savePersisted } from "@/lib/frame/storage";

interface FrameState {
  config: FrameConfig;
  saved: SavedStyle[];
  fileName: string;
  includePhoto: boolean;
  photoUrl: string | null;
  textureUrl: string | null;
  activeBand: 0 | 1 | 2;
  hydrated: boolean;
  patch: (partial: Partial<FrameConfig>) => void;
  setBand: (index: 0 | 1 | 2, color: string) => void;
  setRatio: (index: 0 | 1 | 2, value: number) => void;
  toggleIcon: (icon: string) => void;
  applyPreset: (preset: FramePreset) => void;
  setShape: (shape: FrameShape) => void;
  setDecoType: (decoType: DecoType) => void;
  setTexture: (texture: TextureKind) => void;
  setPhotoUrl: (url: string | null) => void;
  setTextureUrl: (url: string | null) => void;
  setFileName: (name: string) => void;
  setIncludePhoto: (v: boolean) => void;
  setActiveBand: (i: 0 | 1 | 2) => void;
  saveStyle: (name: string) => void;
  loadStyle: (id: string) => void;
  deleteStyle: (id: string) => void;
  clearDecor: () => void;
  resetAll: () => void;
  hydrate: () => void;
}

function persistNow(state: Pick<FrameState, "config" | "saved" | "fileName" | "includePhoto">) {
  savePersisted({
    config: state.config,
    saved: state.saved,
    fileName: state.fileName,
    includePhoto: state.includePhoto,
  });
}

export const useFrameStore = create<FrameState>((set, get) => ({
  config: DEFAULT_CONFIG,
  saved: [],
  fileName: "marco.png",
  includePhoto: false,
  photoUrl: null,
  textureUrl: null,
  activeBand: 0,
  hydrated: false,

  hydrate: () => {
    if (get().hydrated || typeof window === "undefined") return;
    const data = loadPersisted();
    set({ ...data, hydrated: true });
  },

  patch: (partial) => {
    set((s) => {
      const next = { ...s, config: { ...s.config, ...partial } };
      persistNow(next);
      return next;
    });
  },

  setBand: (index, color) => {
    set((s) => {
      const bands = [...s.config.bands] as FrameConfig["bands"];
      bands[index] = color;
      const next = { ...s, config: { ...s.config, bands } };
      persistNow(next);
      return next;
    });
  },

  setRatio: (index, value) => {
    set((s) => {
      const ratios = [...s.config.ratios] as FrameConfig["ratios"];
      ratios[index] = Math.max(0.08, value);
      const sum = ratios[0] + ratios[1] + ratios[2];
      const normalized: FrameConfig["ratios"] = [ratios[0] / sum, ratios[1] / sum, ratios[2] / sum];
      const next = { ...s, config: { ...s.config, ratios: normalized } };
      persistNow(next);
      return next;
    });
  },

  toggleIcon: (icon) => {
    set((s) => {
      const has = s.config.icons.includes(icon);
      const icons = has ? s.config.icons.filter((i) => i !== icon) : [...s.config.icons, icon];
      const next = { ...s, config: { ...s.config, icons } };
      persistNow(next);
      return next;
    });
  },

  applyPreset: (preset) => {
    set((s) => {
      const next = { ...s, config: applyPreset(s.config, preset) };
      persistNow(next);
      return next;
    });
  },

  setShape: (shape) => get().patch({ shape }),
  setDecoType: (decoType) => get().patch({ decoType }),
  setTexture: (texture) => get().patch({ texture }),

  setPhotoUrl: (url) => {
    const prev = get().photoUrl;
    if (prev && prev !== url) URL.revokeObjectURL(prev);
    set({ photoUrl: url });
  },

  setTextureUrl: (url) => {
    const prev = get().textureUrl;
    if (prev && prev !== url) URL.revokeObjectURL(prev);
    set({ textureUrl: url });
    if (url) get().patch({ decoType: "image" });
  },

  setFileName: (fileName) => {
    set((s) => {
      const next = { ...s, fileName };
      persistNow(next);
      return next;
    });
  },

  setIncludePhoto: (includePhoto) => {
    set((s) => {
      const next = { ...s, includePhoto };
      persistNow(next);
      return next;
    });
  },

  setActiveBand: (activeBand) => set({ activeBand }),

  saveStyle: (name) => {
    set((s) => {
      const style: SavedStyle = {
        id: crypto.randomUUID(),
        name: name.trim() || "Estilo",
        createdAt: Date.now(),
        config: { ...s.config },
      };
      const next = { ...s, saved: [style, ...s.saved].slice(0, 24) };
      persistNow(next);
      return next;
    });
  },

  loadStyle: (id) => {
    const found = get().saved.find((x) => x.id === id);
    if (found) get().patch(found.config);
  },

  deleteStyle: (id) => {
    set((s) => {
      const next = { ...s, saved: s.saved.filter((x) => x.id !== id) };
      persistNow(next);
      return next;
    });
  },

  clearDecor: () => {
    get().setTextureUrl(null);
    get().patch({ decoType: "none", icons: [] });
  },

  resetAll: () => {
    get().setPhotoUrl(null);
    get().setTextureUrl(null);
    set((s) => {
      const next = {
        ...s,
        config: DEFAULT_CONFIG,
        includePhoto: false,
        activeBand: 0 as const,
      };
      persistNow(next);
      return next;
    });
  },
}));
