import type { FrameConfig } from "./types";
import { DEFAULT_CONFIG } from "./types";

export interface AspectPreset {
  id: string;
  label: string;
  ratio: string;
  width: number;
  height: number;
}

export const ASPECT_PRESETS: AspectPreset[] = [
  { id: "libre", label: "Libre", ratio: "9∶6.5", width: 900, height: 650 },
  { id: "cuadrado", label: "Cuadrado", ratio: "1∶1", width: 1080, height: 1080 },
  { id: "retrato", label: "Retrato", ratio: "4∶5", width: 1080, height: 1350 },
  { id: "historia", label: "Historia", ratio: "9∶16", width: 1080, height: 1920 },
  { id: "clasico", label: "Clásico", ratio: "4∶3", width: 1200, height: 900 },
  { id: "paisaje", label: "Paisaje", ratio: "16∶9", width: 1920, height: 1080 },
  { id: "foto", label: "Foto", ratio: "3∶2", width: 1500, height: 1000 },
];

export interface FramePreset {
  id: string;
  name: string;
  hint: string;
  config: Partial<FrameConfig>;
}

export const FRAME_PRESETS: FramePreset[] = [
  {
    id: "imperial",
    name: "Imperial",
    hint: "Oro y carmín",
    config: {
      shape: "rounded",
      thickness: 64,
      cornerRadius: 28,
      bands: ["#c9a227", "#6b1220", "#161410"],
      ratios: [0.5, 0.25, 0.25],
      decoType: "icons",
      icons: ["★", "✦"],
      decoColor: "#f0d78c",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "plata",
    name: "Plata",
    hint: "Estaño bruñido",
    config: {
      shape: "rounded",
      thickness: 56,
      cornerRadius: 20,
      bands: ["#c5c8cc", "#6a737b", "#1a1c1e"],
      ratios: [0.45, 0.3, 0.25],
      decoType: "texture",
      texture: "metal",
      decoColor: "#e8eaed",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "nogal",
    name: "Nogal",
    hint: "Madera oscura",
    config: {
      shape: "rect",
      thickness: 72,
      cornerRadius: 0,
      bands: ["#8b5a2b", "#3e2723", "#1a120c"],
      ratios: [0.55, 0.25, 0.2],
      decoType: "texture",
      texture: "madera",
      decoColor: "#c4a574",
      bevel: true,
      innerLine: false,
    },
  },
  {
    id: "marino",
    name: "Marino",
    hint: "Armada y marfil",
    config: {
      shape: "arch",
      thickness: 60,
      cornerRadius: 16,
      bands: ["#1e3a5f", "#c9a86c", "#0b1320"],
      ratios: [0.5, 0.22, 0.28],
      decoType: "icons",
      icons: ["⚜", "◆"],
      decoColor: "#e6d5a8",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "olivo",
    name: "Olivo",
    hint: "Bosque sereno",
    config: {
      shape: "rounded",
      thickness: 58,
      cornerRadius: 36,
      bands: ["#6b7c3a", "#3d4a24", "#1a1c14"],
      ratios: [0.48, 0.28, 0.24],
      decoType: "icons",
      icons: ["☘", "✿"],
      decoColor: "#d5e0b0",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "marfil",
    name: "Marfil",
    hint: "Lino y nogal",
    config: {
      shape: "rounded",
      thickness: 52,
      cornerRadius: 18,
      bands: ["#f3e6c8", "#b89b72", "#3f3328"],
      ratios: [0.5, 0.28, 0.22],
      decoType: "text",
      text: "atelier",
      decoColor: "#5c4636",
      decoSize: 16,
      decoCount: 12,
      bevel: true,
      innerLine: false,
    },
  },
  {
    id: "carbon",
    name: "Carbón",
    hint: "Grafito mate",
    config: {
      shape: "rect",
      thickness: 48,
      cornerRadius: 0,
      bands: ["#3a3a3a", "#161616", "#0a0a0a"],
      ratios: [0.4, 0.35, 0.25],
      decoType: "none",
      decoColor: "#c0c0c0",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "carmesi",
    name: "Carmesí",
    hint: "Teatro antiguo",
    config: {
      shape: "oval",
      thickness: 70,
      cornerRadius: 40,
      bands: ["#8b1e3f", "#c9a227", "#1a0a10"],
      ratios: [0.52, 0.2, 0.28],
      decoType: "icons",
      icons: ["♥", "❀"],
      decoColor: "#f0d78c",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "artico",
    name: "Ártico",
    hint: "Hielo y pizarra",
    config: {
      shape: "circle",
      thickness: 54,
      cornerRadius: 0,
      bands: ["#d9e2ea", "#7a8b99", "#1b242c"],
      ratios: [0.46, 0.3, 0.24],
      decoType: "texture",
      texture: "puntos",
      decoColor: "#eef3f7",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "ocaso",
    name: "Ocaso",
    hint: "Terracota",
    config: {
      shape: "rounded",
      thickness: 62,
      cornerRadius: 22,
      bands: ["#c45c26", "#5c1a1a", "#1a0e08"],
      ratios: [0.5, 0.25, 0.25],
      decoType: "texture",
      texture: "ondas",
      decoColor: "#f0c48c",
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "barroco",
    name: "Barroco",
    hint: "Ornamento rico",
    config: {
      shape: "rounded",
      thickness: 80,
      cornerRadius: 32,
      bands: ["#b8860b", "#4a0e16", "#120e0a"],
      ratios: [0.42, 0.33, 0.25],
      decoType: "texture",
      texture: "barroco",
      decoColor: "#ffe9a8",
      decoSize: 28,
      decoCount: 24,
      bevel: true,
      innerLine: true,
    },
  },
  {
    id: "floral",
    name: "Floral",
    hint: "Jardín íntimo",
    config: {
      shape: "arch",
      thickness: 60,
      cornerRadius: 24,
      bands: ["#5c4033", "#d4a5a5", "#2a1810"],
      ratios: [0.5, 0.22, 0.28],
      decoType: "icons",
      icons: ["✿", "❀", "❁"],
      decoColor: "#f3d6d6",
      decoSize: 20,
      decoCount: 22,
      bevel: true,
      innerLine: true,
    },
  },
];

export function applyPreset(base: FrameConfig, preset: FramePreset): FrameConfig {
  return { ...base, ...preset.config, bands: preset.config.bands ?? base.bands };
}

export function withDefaults(partial: Partial<FrameConfig>): FrameConfig {
  return { ...DEFAULT_CONFIG, ...partial };
}
