export type FrameShape = "rect" | "rounded" | "circle" | "oval" | "arch";

export type DecoType = "none" | "icons" | "text" | "both" | "texture" | "image";

export type TextureKind =
  | "oro"
  | "metal"
  | "barroco"
  | "puntos"
  | "lineas"
  | "cuadros"
  | "ondas"
  | "floral"
  | "madera"
  | "damasco";

export interface FrameConfig {
  width: number;
  height: number;
  shape: FrameShape;
  thickness: number;
  cornerRadius: number;
  bands: [string, string, string];
  ratios: [number, number, number];
  decoType: DecoType;
  icons: string[];
  text: string;
  texture: TextureKind;
  decoColor: string;
  decoSize: number;
  decoCount: number;
  bevel: boolean;
  innerLine: boolean;
}

export interface SavedStyle {
  id: string;
  name: string;
  createdAt: number;
  config: FrameConfig;
}

export interface ContourPoint {
  x: number;
  y: number;
  angle: number;
}

export const MIN_SIZE = 300;
export const MAX_SIZE = 3000;

export const DEFAULT_CONFIG: FrameConfig = {
  width: 900,
  height: 650,
  shape: "rounded",
  thickness: 64,
  cornerRadius: 28,
  bands: ["#c9a227", "#6b1220", "#161410"],
  ratios: [0.5, 0.25, 0.25],
  decoType: "none",
  icons: ["★"],
  text: "kmell",
  texture: "oro",
  decoColor: "#f0d78c",
  decoSize: 22,
  decoCount: 20,
  bevel: true,
  innerLine: true,
};

export const ORNAMENTS = [
  "★",
  "♥",
  "✦",
  "◆",
  "●",
  "▲",
  "✿",
  "⚜",
  "⚔",
  "☘",
  "☀",
  "☾",
  "❖",
  "♛",
  "♚",
  "♦",
  "♣",
  "♠",
  "✧",
  "✪",
  "✯",
  "❀",
  "❁",
  "❂",
  "⚡",
  "❄",
  "☽",
  "✈",
  "✎",
  "♪",
  "♫",
  "☁",
  "☂",
  "☃",
  "♔",
  "♕",
] as const;

export const PALETTE = [
  "#c9a227",
  "#ffd700",
  "#b8860b",
  "#daa520",
  "#f0e68c",
  "#ffec8b",
  "#cd853f",
  "#d2691e",
  "#8b4513",
  "#a0522d",
  "#deb887",
  "#f4a460",
  "#c0c0c0",
  "#a8a8a8",
  "#708090",
  "#2f4f4f",
  "#1c1c1c",
  "#696969",
  "#8b0000",
  "#a52a2a",
  "#dc143c",
  "#ff4500",
  "#ff6347",
  "#b22222",
  "#006400",
  "#228b22",
  "#2e8b57",
  "#3cb371",
  "#20b2aa",
  "#008080",
  "#000080",
  "#191970",
  "#4169e1",
  "#1e90ff",
  "#00bfff",
  "#4682b4",
  "#4b0082",
  "#8a2be2",
  "#9932cc",
  "#ba55d3",
  "#ffffff",
  "#f5f5f5",
  "#dcdcdc",
  "#d3d3d3",
  "#a9a9a9",
  "#808080",
  "#f3e6c8",
  "#3e2723",
] as const;
