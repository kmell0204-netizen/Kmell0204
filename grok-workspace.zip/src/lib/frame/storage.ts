import type { FrameConfig, SavedStyle } from "./types";
import { DEFAULT_CONFIG } from "./types";

const KEY = "marco_atelier_v1";

interface PersistShape {
  config: FrameConfig;
  saved: SavedStyle[];
  fileName: string;
  includePhoto: boolean;
}

function isConfig(v: unknown): v is FrameConfig {
  if (!v || typeof v !== "object") return false;
  const c = v as FrameConfig;
  return typeof c.width === "number" && typeof c.height === "number" && Array.isArray(c.bands);
}

export function loadPersisted(): PersistShape {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      return {
        config: DEFAULT_CONFIG,
        saved: [],
        fileName: "marco.png",
        includePhoto: false,
      };
    }
    const parsed = JSON.parse(raw) as Partial<PersistShape>;
    return {
      config: isConfig(parsed.config) ? { ...DEFAULT_CONFIG, ...parsed.config } : DEFAULT_CONFIG,
      saved: Array.isArray(parsed.saved) ? parsed.saved : [],
      fileName: typeof parsed.fileName === "string" ? parsed.fileName : "marco.png",
      includePhoto: Boolean(parsed.includePhoto),
    };
  } catch {
    return {
      config: DEFAULT_CONFIG,
      saved: [],
      fileName: "marco.png",
      includePhoto: false,
    };
  }
}

export function savePersisted(data: PersistShape) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // quota / private mode
  }
}
