import { canvasPngBlob, renderToCanvas, type DrawExtras } from "./draw";
import type { FrameConfig } from "./types";

function safeFileName(name: string) {
  const trimmed = name.trim() || "marco.png";
  return trimmed.toLowerCase().endsWith(".png") ? trimmed : `${trimmed}.png`;
}

export async function downloadPng(
  config: FrameConfig,
  extras: DrawExtras,
  fileName: string,
  directoryHandle: FileSystemDirectoryHandle | null,
) {
  const canvas = renderToCanvas(config, extras);
  const blob = await canvasPngBlob(canvas);
  const name = safeFileName(fileName);

  if (directoryHandle) {
    const fileHandle = await directoryHandle.getFileHandle(name, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(blob);
    await writable.close();
    return { method: "folder" as const, name };
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  return { method: "download" as const, name };
}

export async function copyPng(config: FrameConfig, extras: DrawExtras) {
  const canvas = renderToCanvas(config, extras);
  const blob = await canvasPngBlob(canvas);
  await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
}

export async function pickDirectory(): Promise<FileSystemDirectoryHandle> {
  if (!("showDirectoryPicker" in window) || typeof window.showDirectoryPicker !== "function") {
    throw new Error("unsupported");
  }
  return window.showDirectoryPicker();
}
