import type {
  ContourPoint,
  FrameConfig,
  FrameShape,
  TextureKind,
} from "./types";

export interface DrawExtras {
  photo?: CanvasImageSource | null;
  textureImg?: CanvasImageSource | null;
  includePhoto?: boolean;
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function maxThickness(w: number, h: number) {
  return Math.max(12, Math.min(w, h) / 2 - 10);
}

function normalizedRatios(r: [number, number, number]): [number, number, number] {
  const sum = r[0] + r[1] + r[2];
  if (sum <= 0) return [0.5, 0.25, 0.25];
  return [r[0] / sum, r[1] / sum, r[2] / sum];
}

export function addShapePath(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  inset: number,
  shape: FrameShape,
  cornerRadius: number,
) {
  const x = inset;
  const y = inset;
  const rw = w - inset * 2;
  const rh = h - inset * 2;
  if (rw <= 1 || rh <= 1) return;

  if (shape === "circle") {
    const r = Math.min(rw, rh) / 2;
    ctx.moveTo(w / 2 + r, h / 2);
    ctx.arc(w / 2, h / 2, r, 0, Math.PI * 2);
    ctx.closePath();
    return;
  }

  if (shape === "oval") {
    ctx.moveTo(w / 2 + rw / 2, h / 2);
    ctx.ellipse(w / 2, h / 2, rw / 2, rh / 2, 0, 0, Math.PI * 2);
    ctx.closePath();
    return;
  }

  if (shape === "arch") {
    const cap = Math.min(rw / 2, rh * 0.55);
    ctx.moveTo(x, y + cap);
    ctx.arc(x + rw / 2, y + cap, cap, Math.PI, 0, false);
    ctx.lineTo(x + rw, y + rh);
    ctx.lineTo(x, y + rh);
    ctx.closePath();
    return;
  }

  const r =
    shape === "rounded"
      ? Math.max(0, Math.min(cornerRadius - inset * 0.12, rw / 2, rh / 2))
      : 0;

  if (r > 0.5) {
    ctx.roundRect(x, y, rw, rh, r);
  } else {
    ctx.rect(x, y, rw, rh);
  }
}

function fillBand(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  outer: number,
  inner: number,
  color: string,
  shape: FrameShape,
  radius: number,
) {
  if (inner <= outer + 0.5) return;
  ctx.beginPath();
  addShapePath(ctx, w, h, outer, shape, radius);
  addShapePath(ctx, w, h, inner, shape, radius);
  ctx.fillStyle = color;
  ctx.fill("evenodd");
}

function coverImage(
  ctx: CanvasRenderingContext2D,
  img: CanvasImageSource,
  w: number,
  h: number,
) {
  const iw =
    "width" in img && typeof img.width === "number" && img.width > 0
      ? img.width
      : w;
  const ih =
    "height" in img && typeof img.height === "number" && img.height > 0
      ? img.height
      : h;
  const scale = Math.max(w / iw, h / ih);
  const dw = iw * scale;
  const dh = ih * scale;
  ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
}

type Seg = { len: number; at: (d: number) => ContourPoint };

function sampleSegs(segs: Seg[], count: number): ContourPoint[] {
  const usable = segs.filter((s) => s.len > 0.25);
  const total = usable.reduce((s, g) => s + g.len, 0);
  const pts: ContourPoint[] = [];
  if (total <= 0 || count <= 0) return pts;
  for (let i = 0; i < count; i++) {
    let dist = ((i + 0.5) / count) * total;
    for (const seg of usable) {
      if (dist <= seg.len) {
        pts.push(seg.at(clamp(dist, 0, seg.len)));
        break;
      }
      dist -= seg.len;
    }
  }
  return pts;
}

function roundedContour(
  w: number,
  h: number,
  inset: number,
  radius: number,
  count: number,
): ContourPoint[] {
  const x = inset;
  const y = inset;
  const rw = w - inset * 2;
  const rh = h - inset * 2;
  const r = Math.max(0, Math.min(radius, rw / 2, rh / 2));
  const sw = Math.max(0, rw - 2 * r);
  const sh = Math.max(0, rh - 2 * r);
  const al = (Math.PI * r) / 2;

  const segs: Seg[] = [
    { len: sw, at: (d) => ({ x: x + r + d, y, angle: 0 }) },
    {
      len: al,
      at: (d) => {
        const a = -Math.PI / 2 + (d / al) * (Math.PI / 2);
        return {
          x: x + rw - r + Math.cos(a) * r,
          y: y + r + Math.sin(a) * r,
          angle: a + Math.PI / 2,
        };
      },
    },
    { len: sh, at: (d) => ({ x: x + rw, y: y + r + d, angle: Math.PI / 2 }) },
    {
      len: al,
      at: (d) => {
        const a = 0 + (d / al) * (Math.PI / 2);
        return {
          x: x + rw - r + Math.cos(a) * r,
          y: y + rh - r + Math.sin(a) * r,
          angle: a + Math.PI / 2,
        };
      },
    },
    { len: sw, at: (d) => ({ x: x + rw - r - d, y: y + rh, angle: Math.PI }) },
    {
      len: al,
      at: (d) => {
        const a = Math.PI / 2 + (d / al) * (Math.PI / 2);
        return {
          x: x + r + Math.cos(a) * r,
          y: y + rh - r + Math.sin(a) * r,
          angle: a + Math.PI / 2,
        };
      },
    },
    { len: sh, at: (d) => ({ x, y: y + rh - r - d, angle: -Math.PI / 2 }) },
    {
      len: al,
      at: (d) => {
        const a = Math.PI + (d / al) * (Math.PI / 2);
        return {
          x: x + r + Math.cos(a) * r,
          y: y + r + Math.sin(a) * r,
          angle: a + Math.PI / 2,
        };
      },
    },
  ];
  return sampleSegs(segs, count);
}

export function contourPoints(
  w: number,
  h: number,
  inset: number,
  count: number,
  shape: FrameShape,
  cornerRadius: number,
): ContourPoint[] {
  if (shape === "circle") {
    const r = Math.min(w, h) / 2 - inset;
    const pts: ContourPoint[] = [];
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2 - Math.PI / 2;
      pts.push({
        x: w / 2 + Math.cos(a) * r,
        y: h / 2 + Math.sin(a) * r,
        angle: a + Math.PI / 2,
      });
    }
    return pts;
  }

  if (shape === "oval") {
    const rx = w / 2 - inset;
    const ry = h / 2 - inset;
    const pts: ContourPoint[] = [];
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2 - Math.PI / 2;
      pts.push({
        x: w / 2 + Math.cos(a) * rx,
        y: h / 2 + Math.sin(a) * ry,
        angle: Math.atan2(ry * Math.cos(a), -rx * Math.sin(a)),
      });
    }
    return pts;
  }

  if (shape === "arch") {
    const x = inset;
    const y = inset;
    const rw = w - inset * 2;
    const rh = h - inset * 2;
    const cap = Math.min(rw / 2, rh * 0.55);
    const cx = x + rw / 2;
    const cy = y + cap;
    const side = Math.max(0, rh - cap);
    const segs: Seg[] = [
      {
        len: Math.PI * cap,
        at: (d) => {
          const tot = Math.PI * cap;
          const a = Math.PI + (d / tot) * Math.PI;
          return {
            x: cx + Math.cos(a) * cap,
            y: cy + Math.sin(a) * cap,
            angle: a + Math.PI / 2,
          };
        },
      },
      { len: side, at: (d) => ({ x: x + rw, y: y + cap + d, angle: Math.PI / 2 }) },
      { len: rw, at: (d) => ({ x: x + rw - d, y: y + rh, angle: Math.PI }) },
      { len: side, at: (d) => ({ x, y: y + rh - d, angle: -Math.PI / 2 }) },
    ];
    return sampleSegs(segs, count);
  }

  const r = shape === "rounded" ? cornerRadius - inset * 0.12 : 0;
  return roundedContour(w, h, inset, Math.max(0, r), count);
}

function makeTile(kind: TextureKind, color: string, size: number): HTMLCanvasElement {
  const s = Math.max(32, Math.round(size * 2.4));
  const tile = document.createElement("canvas");
  tile.width = s;
  tile.height = s;
  const c = tile.getContext("2d");
  if (!c) return tile;

  if (kind === "oro" || kind === "metal") {
    const g = c.createLinearGradient(0, 0, s, 0);
    if (kind === "oro") {
      g.addColorStop(0, "#6a4e12");
      g.addColorStop(0.28, color);
      g.addColorStop(0.5, "#fff6d4");
      g.addColorStop(0.72, color);
      g.addColorStop(1, "#6a4e12");
    } else {
      g.addColorStop(0, "#55565a");
      g.addColorStop(0.35, "#d8dbe0");
      g.addColorStop(0.5, "#ffffff");
      g.addColorStop(0.7, color);
      g.addColorStop(1, "#55565a");
    }
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
    c.strokeStyle = "rgba(255,255,255,0.12)";
    c.lineWidth = 1;
    for (let y = 0; y < s; y += 3) {
      c.beginPath();
      c.moveTo(0, y);
      c.lineTo(s, y);
      c.stroke();
    }
    return tile;
  }

  c.fillStyle = "transparent";
  c.fillRect(0, 0, s, s);
  c.fillStyle = color;
  c.strokeStyle = color;

  if (kind === "puntos") {
    for (let y = 8; y < s; y += 16) {
      for (let x = 8; x < s; x += 16) {
        c.beginPath();
        c.arc(x, y, 2.4, 0, Math.PI * 2);
        c.fill();
      }
    }
  } else if (kind === "lineas") {
    c.lineWidth = 1.4;
    for (let i = -s; i < s * 2; i += 8) {
      c.beginPath();
      c.moveTo(i, 0);
      c.lineTo(i + s, s);
      c.stroke();
    }
  } else if (kind === "cuadros") {
    const cell = s / 4;
    for (let y = 0; y < 4; y++) {
      for (let x = 0; x < 4; x++) {
        if ((x + y) % 2 === 0) c.fillRect(x * cell, y * cell, cell, cell);
      }
    }
  } else if (kind === "ondas") {
    c.lineWidth = 1.6;
    for (let y = 6; y < s; y += 12) {
      c.beginPath();
      for (let x = 0; x <= s; x++) {
        const yy = y + Math.sin((x / s) * Math.PI * 2) * 4;
        if (x === 0) c.moveTo(x, yy);
        else c.lineTo(x, yy);
      }
      c.stroke();
    }
  } else if (kind === "floral") {
    const drawFlower = (cx: number, cy: number, r: number) => {
      for (let a = 0; a < 5; a++) {
        c.save();
        c.translate(cx, cy);
        c.rotate((a * 72 * Math.PI) / 180);
        c.beginPath();
        c.ellipse(0, -r * 0.45, r * 0.28, r * 0.5, 0, 0, Math.PI * 2);
        c.fill();
        c.restore();
      }
      c.beginPath();
      c.arc(cx, cy, r * 0.22, 0, Math.PI * 2);
      c.fill();
    };
    drawFlower(s * 0.32, s * 0.32, s * 0.2);
    drawFlower(s * 0.72, s * 0.7, s * 0.16);
  } else if (kind === "barroco") {
    c.lineWidth = 1.5;
    c.beginPath();
    c.moveTo(s * 0.15, s * 0.5);
    c.bezierCurveTo(s * 0.15, s * 0.15, s * 0.5, s * 0.15, s * 0.5, s * 0.5);
    c.bezierCurveTo(s * 0.5, s * 0.85, s * 0.85, s * 0.85, s * 0.85, s * 0.5);
    c.stroke();
    c.beginPath();
    c.arc(s * 0.5, s * 0.5, s * 0.08, 0, Math.PI * 2);
    c.fill();
    c.beginPath();
    c.moveTo(s * 0.5, s * 0.18);
    c.quadraticCurveTo(s * 0.72, s * 0.32, s * 0.5, s * 0.42);
    c.quadraticCurveTo(s * 0.28, s * 0.32, s * 0.5, s * 0.18);
    c.fill();
  } else if (kind === "madera") {
    const g = c.createLinearGradient(0, 0, 0, s);
    g.addColorStop(0, color);
    g.addColorStop(1, "#3e2723");
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
    c.strokeStyle = "rgba(0,0,0,0.22)";
    c.lineWidth = 1;
    for (let i = 0; i < 14; i++) {
      c.beginPath();
      for (let x = 0; x <= s; x++) {
        const y =
          ((i + 1) * s) / 15 +
          Math.sin(x / 7 + i * 0.7) * 3 +
          Math.sin(x / 2.4 + i) * 1.1;
        if (x === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
      }
      c.stroke();
    }
  } else if (kind === "damasco") {
    c.lineWidth = 1.2;
    c.translate(s / 2, s / 2);
    c.rotate(Math.PI / 4);
    for (let i = 0; i < 3; i++) {
      const k = 6 + i * 7;
      c.strokeRect(-k, -k, k * 2, k * 2);
    }
    c.beginPath();
    c.arc(0, 0, 4, 0, Math.PI * 2);
    c.fill();
  }

  return tile;
}

function overlayTexture(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  shape: FrameShape,
  radius: number,
  kind: TextureKind,
  color: string,
  size: number,
  image?: CanvasImageSource | null,
) {
  ctx.save();
  ctx.beginPath();
  addShapePath(ctx, w, h, 0, shape, radius);
  addShapePath(ctx, w, h, t, shape, radius);
  ctx.clip("evenodd");

  let pattern: CanvasPattern | null = null;
  if (image) {
    pattern = ctx.createPattern(image as CanvasImageSource, "repeat");
  } else {
    const tile = makeTile(kind, color, size);
    pattern = ctx.createPattern(tile, "repeat");
  }
  if (pattern) {
    ctx.globalAlpha = image ? 0.72 : 0.55;
    ctx.globalCompositeOperation = "overlay";
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

function drawBevel(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  shape: FrameShape,
  radius: number,
) {
  ctx.save();
  ctx.beginPath();
  addShapePath(ctx, w, h, 0.8, shape, radius);
  ctx.strokeStyle = "rgba(255,255,255,0.28)";
  ctx.lineWidth = Math.max(1, t * 0.03);
  ctx.stroke();

  ctx.beginPath();
  addShapePath(ctx, w, h, t * 0.5, shape, radius);
  ctx.strokeStyle = "rgba(0,0,0,0.18)";
  ctx.lineWidth = Math.max(1, t * 0.025);
  ctx.stroke();

  ctx.shadowColor = "rgba(0,0,0,0.45)";
  ctx.shadowBlur = Math.max(6, t * 0.14);
  ctx.beginPath();
  addShapePath(ctx, w, h, t, shape, radius);
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

function drawInnerLine(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  shape: FrameShape,
  radius: number,
  color: string,
) {
  ctx.save();
  ctx.beginPath();
  addShapePath(ctx, w, h, t - 3, shape, radius);
  ctx.strokeStyle = color;
  ctx.globalAlpha = 0.85;
  ctx.lineWidth = 1.4;
  ctx.stroke();
  ctx.restore();
}

function stampOrnaments(
  ctx: CanvasRenderingContext2D,
  pts: ContourPoint[],
  config: FrameConfig,
) {
  const size = config.decoSize;
  const type = config.decoType;
  const icons = config.icons.length > 0 ? config.icons : ["★"];

  pts.forEach((p, i) => {
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);
    ctx.fillStyle = config.decoColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    if (type === "icons" || type === "both") {
      ctx.font = `600 ${size}px "Segoe UI Symbol", "Noto Sans Symbols", Georgia, serif`;
      ctx.fillText(icons[i % icons.length] ?? "★", 0, type === "both" ? -size * 0.15 : 0);
    }
    if (type === "text" || type === "both") {
      const txt = config.text.trim() || "•";
      ctx.font = `600 ${Math.max(10, size * 0.72)}px "Cormorant Garamond", Georgia, serif`;
      const extraY = type === "both" ? size * 0.7 : 0;
      ctx.fillText(txt, 0, extraY);
    }
    ctx.restore();
  });
}

function stampTextureMotifs(
  ctx: CanvasRenderingContext2D,
  pts: ContourPoint[],
  config: FrameConfig,
  image?: CanvasImageSource | null,
) {
  const size = config.decoSize;
  const kind = config.texture;

  pts.forEach((p) => {
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);

    if (image) {
      const s = size * 1.6;
      ctx.drawImage(image, -s / 2, -s / 2, s, s);
      ctx.restore();
      return;
    }

    if (kind === "oro" || kind === "metal") {
      const g = ctx.createLinearGradient(-size, 0, size, 0);
      if (kind === "oro") {
        g.addColorStop(0, "#8B6914");
        g.addColorStop(0.35, "#FFD700");
        g.addColorStop(0.65, "#FFF8DC");
        g.addColorStop(1, "#8B6914");
      } else {
        g.addColorStop(0, "#555");
        g.addColorStop(0.4, "#DDD");
        g.addColorStop(0.6, "#FFF");
        g.addColorStop(1, "#555");
      }
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(0, 0, size * 0.65, size * 0.28, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "barroco") {
      ctx.fillStyle = config.decoColor;
      ctx.beginPath();
      ctx.moveTo(0, -size * 0.45);
      ctx.quadraticCurveTo(size * 0.45, -size * 0.15, size * 0.35, size * 0.25);
      ctx.quadraticCurveTo(0, size * 0.45, -size * 0.35, size * 0.25);
      ctx.quadraticCurveTo(-size * 0.45, -size * 0.15, 0, -size * 0.45);
      ctx.fill();
    } else if (kind === "puntos") {
      ctx.fillStyle = config.decoColor;
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.28, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "lineas") {
      ctx.strokeStyle = config.decoColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-size * 0.55, -size * 0.2);
      ctx.lineTo(size * 0.55, size * 0.2);
      ctx.stroke();
    } else if (kind === "cuadros") {
      ctx.fillStyle = config.decoColor;
      ctx.fillRect(-size * 0.28, -size * 0.28, size * 0.56, size * 0.56);
    } else if (kind === "ondas") {
      ctx.strokeStyle = config.decoColor;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(-size * 0.6, 0);
      ctx.quadraticCurveTo(-size * 0.15, -size * 0.4, 0, 0);
      ctx.quadraticCurveTo(size * 0.15, size * 0.4, size * 0.6, 0);
      ctx.stroke();
    } else if (kind === "floral") {
      ctx.fillStyle = config.decoColor;
      for (let a = 0; a < 5; a++) {
        ctx.beginPath();
        ctx.ellipse(0, -size * 0.22, size * 0.15, size * 0.28, (a * 72 * Math.PI) / 180, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.12, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "madera") {
      ctx.fillStyle = config.decoColor;
      ctx.fillRect(-size * 0.7, -size * 0.18, size * 1.4, size * 0.36);
    } else if (kind === "damasco") {
      ctx.fillStyle = config.decoColor;
      ctx.beginPath();
      ctx.moveTo(0, -size * 0.4);
      ctx.lineTo(size * 0.28, 0);
      ctx.lineTo(0, size * 0.4);
      ctx.lineTo(-size * 0.28, 0);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  });
}

export function drawFrame(
  ctx: CanvasRenderingContext2D,
  config: FrameConfig,
  extras: DrawExtras = {},
) {
  const w = config.width;
  const h = config.height;
  const t = clamp(config.thickness, 12, maxThickness(w, h));
  const shape = config.shape;
  const radius = config.cornerRadius;
  const ratios = normalizedRatios(config.ratios);

  ctx.clearRect(0, 0, w, h);

  if (extras.includePhoto && extras.photo) {
    coverImage(ctx, extras.photo, w, h);
  }

  const g0 = t * ratios[0];
  const g1 = t * ratios[1];
  const g2 = t * ratios[2];

  fillBand(ctx, w, h, 0, g0, config.bands[0], shape, radius);
  fillBand(ctx, w, h, g0, g0 + g1, config.bands[1], shape, radius);
  fillBand(ctx, w, h, g0 + g1, g0 + g1 + g2, config.bands[2], shape, radius);

  if (config.decoType === "texture") {
    overlayTexture(ctx, w, h, t, shape, radius, config.texture, config.decoColor, config.decoSize);
  } else if (config.decoType === "image" && extras.textureImg) {
    overlayTexture(
      ctx,
      w,
      h,
      t,
      shape,
      radius,
      config.texture,
      config.decoColor,
      config.decoSize,
      extras.textureImg,
    );
  }

  if (config.bevel) {
    drawBevel(ctx, w, h, t, shape, radius);
  }
  if (config.innerLine) {
    drawInnerLine(ctx, w, h, t, shape, radius, config.decoColor);
  }

  if (config.decoType === "none") return;

  const decoInset = g0 + g1 * 0.5;
  const pts = contourPoints(w, h, decoInset, config.decoCount, shape, radius);

  if (config.decoType === "texture" || config.decoType === "image") {
    stampTextureMotifs(
      ctx,
      pts,
      config,
      config.decoType === "image" ? extras.textureImg : null,
    );
    return;
  }

  stampOrnaments(ctx, pts, config);
}

export function renderToCanvas(
  config: FrameConfig,
  extras: DrawExtras = {},
): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = config.width;
  canvas.height = config.height;
  const ctx = canvas.getContext("2d");
  if (ctx) drawFrame(ctx, config, extras);
  return canvas;
}

export async function canvasPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/png"),
  );
  if (!blob) throw new Error("No se pudo generar el PNG");
  return blob;
}
