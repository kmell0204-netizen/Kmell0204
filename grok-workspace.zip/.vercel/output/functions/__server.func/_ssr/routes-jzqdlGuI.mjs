import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Save, c as ImagePlus, d as Download, f as Copy, h as Check, i as Square, l as Frame, m as ChevronDown, o as RotateCcw, p as Circle, r as Trash2, s as RectangleHorizontal, t as X, u as FolderOpen } from "../_libs/lucide-react.mjs";
import { a as SelectItemIndicator, c as SelectTrigger$1, i as SelectItem$1, l as SelectValue$1, n as SelectContent$1, o as SelectItemText, r as SelectIcon, s as SelectPortal, t as Select$1, u as SelectViewport } from "../_libs/@radix-ui/react-select+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as cn } from "./router-CUxu8ivN.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { t as Root$1 } from "../_libs/radix-ui__react-separator.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/radix-ui__react-slider.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-jzqdlGuI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent shadow-[var(--shadow-border)]",
			outline: "border border-border bg-transparent text-foreground hover:bg-accent",
			ghost: "text-foreground hover:bg-accent",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 rounded-sm px-3 text-xs",
			lg: "h-12 min-h-12 px-5",
			icon: "size-11 min-h-11 min-w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground shadow-[var(--shadow-border)] transition-[box-shadow,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-border bg-surface-2 transition-colors duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring data-[state=checked]:bg-primary", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 rounded-full bg-foreground shadow-sm transition-transform duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)] data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0.5 data-[state=checked]:bg-primary-foreground") })
}));
Switch.displayName = Switch$1.displayName;
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function maxThickness(w, h) {
	return Math.max(12, Math.min(w, h) / 2 - 10);
}
function normalizedRatios(r) {
	const sum = r[0] + r[1] + r[2];
	if (sum <= 0) return [
		.5,
		.25,
		.25
	];
	return [
		r[0] / sum,
		r[1] / sum,
		r[2] / sum
	];
}
function addShapePath(ctx, w, h, inset, shape, cornerRadius) {
	const x = inset;
	const y = inset;
	const rw = w - inset * 2;
	const rh = h - inset * 2;
	if (rw <= 1 || rh <= 1) return;
	if (shape === "circle") {
		const r = Math.min(rw, rh) / 2;
		ctx.moveTo(w / 2 + r, h / 2);
		ctx.arc(w / 2, h / 2, r, 0, Math.PI * 2);
		ctx.closePath();
		return;
	}
	if (shape === "oval") {
		ctx.moveTo(w / 2 + rw / 2, h / 2);
		ctx.ellipse(w / 2, h / 2, rw / 2, rh / 2, 0, 0, Math.PI * 2);
		ctx.closePath();
		return;
	}
	if (shape === "arch") {
		const cap = Math.min(rw / 2, rh * .55);
		ctx.moveTo(x, y + cap);
		ctx.arc(x + rw / 2, y + cap, cap, Math.PI, 0, false);
		ctx.lineTo(x + rw, y + rh);
		ctx.lineTo(x, y + rh);
		ctx.closePath();
		return;
	}
	const r = shape === "rounded" ? Math.max(0, Math.min(cornerRadius - inset * .12, rw / 2, rh / 2)) : 0;
	if (r > .5) ctx.roundRect(x, y, rw, rh, r);
	else ctx.rect(x, y, rw, rh);
}
function fillBand(ctx, w, h, outer, inner, color, shape, radius) {
	if (inner <= outer + .5) return;
	ctx.beginPath();
	addShapePath(ctx, w, h, outer, shape, radius);
	addShapePath(ctx, w, h, inner, shape, radius);
	ctx.fillStyle = color;
	ctx.fill("evenodd");
}
function coverImage(ctx, img, w, h) {
	const iw = "width" in img && typeof img.width === "number" && img.width > 0 ? img.width : w;
	const ih = "height" in img && typeof img.height === "number" && img.height > 0 ? img.height : h;
	const scale = Math.max(w / iw, h / ih);
	const dw = iw * scale;
	const dh = ih * scale;
	ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
}
function sampleSegs(segs, count) {
	const usable = segs.filter((s) => s.len > .25);
	const total = usable.reduce((s, g) => s + g.len, 0);
	const pts = [];
	if (total <= 0 || count <= 0) return pts;
	for (let i = 0; i < count; i++) {
		let dist = (i + .5) / count * total;
		for (const seg of usable) {
			if (dist <= seg.len) {
				pts.push(seg.at(clamp(dist, 0, seg.len)));
				break;
			}
			dist -= seg.len;
		}
	}
	return pts;
}
function roundedContour(w, h, inset, radius, count) {
	const x = inset;
	const y = inset;
	const rw = w - inset * 2;
	const rh = h - inset * 2;
	const r = Math.max(0, Math.min(radius, rw / 2, rh / 2));
	const sw = Math.max(0, rw - 2 * r);
	const sh = Math.max(0, rh - 2 * r);
	const al = Math.PI * r / 2;
	return sampleSegs([
		{
			len: sw,
			at: (d) => ({
				x: x + r + d,
				y,
				angle: 0
			})
		},
		{
			len: al,
			at: (d) => {
				const a = -Math.PI / 2 + d / al * (Math.PI / 2);
				return {
					x: x + rw - r + Math.cos(a) * r,
					y: y + r + Math.sin(a) * r,
					angle: a + Math.PI / 2
				};
			}
		},
		{
			len: sh,
			at: (d) => ({
				x: x + rw,
				y: y + r + d,
				angle: Math.PI / 2
			})
		},
		{
			len: al,
			at: (d) => {
				const a = 0 + d / al * (Math.PI / 2);
				return {
					x: x + rw - r + Math.cos(a) * r,
					y: y + rh - r + Math.sin(a) * r,
					angle: a + Math.PI / 2
				};
			}
		},
		{
			len: sw,
			at: (d) => ({
				x: x + rw - r - d,
				y: y + rh,
				angle: Math.PI
			})
		},
		{
			len: al,
			at: (d) => {
				const a = Math.PI / 2 + d / al * (Math.PI / 2);
				return {
					x: x + r + Math.cos(a) * r,
					y: y + rh - r + Math.sin(a) * r,
					angle: a + Math.PI / 2
				};
			}
		},
		{
			len: sh,
			at: (d) => ({
				x,
				y: y + rh - r - d,
				angle: -Math.PI / 2
			})
		},
		{
			len: al,
			at: (d) => {
				const a = Math.PI + d / al * (Math.PI / 2);
				return {
					x: x + r + Math.cos(a) * r,
					y: y + r + Math.sin(a) * r,
					angle: a + Math.PI / 2
				};
			}
		}
	], count);
}
function contourPoints(w, h, inset, count, shape, cornerRadius) {
	if (shape === "circle") {
		const r = Math.min(w, h) / 2 - inset;
		const pts = [];
		for (let i = 0; i < count; i++) {
			const a = i / count * Math.PI * 2 - Math.PI / 2;
			pts.push({
				x: w / 2 + Math.cos(a) * r,
				y: h / 2 + Math.sin(a) * r,
				angle: a + Math.PI / 2
			});
		}
		return pts;
	}
	if (shape === "oval") {
		const rx = w / 2 - inset;
		const ry = h / 2 - inset;
		const pts = [];
		for (let i = 0; i < count; i++) {
			const a = i / count * Math.PI * 2 - Math.PI / 2;
			pts.push({
				x: w / 2 + Math.cos(a) * rx,
				y: h / 2 + Math.sin(a) * ry,
				angle: Math.atan2(ry * Math.cos(a), -rx * Math.sin(a))
			});
		}
		return pts;
	}
	if (shape === "arch") {
		const x = inset;
		const y = inset;
		const rw = w - inset * 2;
		const rh = h - inset * 2;
		const cap = Math.min(rw / 2, rh * .55);
		const cx = x + rw / 2;
		const cy = y + cap;
		const side = Math.max(0, rh - cap);
		return sampleSegs([
			{
				len: Math.PI * cap,
				at: (d) => {
					const tot = Math.PI * cap;
					const a = Math.PI + d / tot * Math.PI;
					return {
						x: cx + Math.cos(a) * cap,
						y: cy + Math.sin(a) * cap,
						angle: a + Math.PI / 2
					};
				}
			},
			{
				len: side,
				at: (d) => ({
					x: x + rw,
					y: y + cap + d,
					angle: Math.PI / 2
				})
			},
			{
				len: rw,
				at: (d) => ({
					x: x + rw - d,
					y: y + rh,
					angle: Math.PI
				})
			},
			{
				len: side,
				at: (d) => ({
					x,
					y: y + rh - d,
					angle: -Math.PI / 2
				})
			}
		], count);
	}
	const r = shape === "rounded" ? cornerRadius - inset * .12 : 0;
	return roundedContour(w, h, inset, Math.max(0, r), count);
}
function makeTile(kind, color, size) {
	const s = Math.max(32, Math.round(size * 2.4));
	const tile = document.createElement("canvas");
	tile.width = s;
	tile.height = s;
	const c = tile.getContext("2d");
	if (!c) return tile;
	if (kind === "oro" || kind === "metal") {
		const g = c.createLinearGradient(0, 0, s, 0);
		if (kind === "oro") {
			g.addColorStop(0, "#6a4e12");
			g.addColorStop(.28, color);
			g.addColorStop(.5, "#fff6d4");
			g.addColorStop(.72, color);
			g.addColorStop(1, "#6a4e12");
		} else {
			g.addColorStop(0, "#55565a");
			g.addColorStop(.35, "#d8dbe0");
			g.addColorStop(.5, "#ffffff");
			g.addColorStop(.7, color);
			g.addColorStop(1, "#55565a");
		}
		c.fillStyle = g;
		c.fillRect(0, 0, s, s);
		c.strokeStyle = "rgba(255,255,255,0.12)";
		c.lineWidth = 1;
		for (let y = 0; y < s; y += 3) {
			c.beginPath();
			c.moveTo(0, y);
			c.lineTo(s, y);
			c.stroke();
		}
		return tile;
	}
	c.fillStyle = "transparent";
	c.fillRect(0, 0, s, s);
	c.fillStyle = color;
	c.strokeStyle = color;
	if (kind === "puntos") for (let y = 8; y < s; y += 16) for (let x = 8; x < s; x += 16) {
		c.beginPath();
		c.arc(x, y, 2.4, 0, Math.PI * 2);
		c.fill();
	}
	else if (kind === "lineas") {
		c.lineWidth = 1.4;
		for (let i = -s; i < s * 2; i += 8) {
			c.beginPath();
			c.moveTo(i, 0);
			c.lineTo(i + s, s);
			c.stroke();
		}
	} else if (kind === "cuadros") {
		const cell = s / 4;
		for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if ((x + y) % 2 === 0) c.fillRect(x * cell, y * cell, cell, cell);
	} else if (kind === "ondas") {
		c.lineWidth = 1.6;
		for (let y = 6; y < s; y += 12) {
			c.beginPath();
			for (let x = 0; x <= s; x++) {
				const yy = y + Math.sin(x / s * Math.PI * 2) * 4;
				if (x === 0) c.moveTo(x, yy);
				else c.lineTo(x, yy);
			}
			c.stroke();
		}
	} else if (kind === "floral") {
		const drawFlower = (cx, cy, r) => {
			for (let a = 0; a < 5; a++) {
				c.save();
				c.translate(cx, cy);
				c.rotate(a * 72 * Math.PI / 180);
				c.beginPath();
				c.ellipse(0, -r * .45, r * .28, r * .5, 0, 0, Math.PI * 2);
				c.fill();
				c.restore();
			}
			c.beginPath();
			c.arc(cx, cy, r * .22, 0, Math.PI * 2);
			c.fill();
		};
		drawFlower(s * .32, s * .32, s * .2);
		drawFlower(s * .72, s * .7, s * .16);
	} else if (kind === "barroco") {
		c.lineWidth = 1.5;
		c.beginPath();
		c.moveTo(s * .15, s * .5);
		c.bezierCurveTo(s * .15, s * .15, s * .5, s * .15, s * .5, s * .5);
		c.bezierCurveTo(s * .5, s * .85, s * .85, s * .85, s * .85, s * .5);
		c.stroke();
		c.beginPath();
		c.arc(s * .5, s * .5, s * .08, 0, Math.PI * 2);
		c.fill();
		c.beginPath();
		c.moveTo(s * .5, s * .18);
		c.quadraticCurveTo(s * .72, s * .32, s * .5, s * .42);
		c.quadraticCurveTo(s * .28, s * .32, s * .5, s * .18);
		c.fill();
	} else if (kind === "madera") {
		const g = c.createLinearGradient(0, 0, 0, s);
		g.addColorStop(0, color);
		g.addColorStop(1, "#3e2723");
		c.fillStyle = g;
		c.fillRect(0, 0, s, s);
		c.strokeStyle = "rgba(0,0,0,0.22)";
		c.lineWidth = 1;
		for (let i = 0; i < 14; i++) {
			c.beginPath();
			for (let x = 0; x <= s; x++) {
				const y = (i + 1) * s / 15 + Math.sin(x / 7 + i * .7) * 3 + Math.sin(x / 2.4 + i) * 1.1;
				if (x === 0) c.moveTo(x, y);
				else c.lineTo(x, y);
			}
			c.stroke();
		}
	} else if (kind === "damasco") {
		c.lineWidth = 1.2;
		c.translate(s / 2, s / 2);
		c.rotate(Math.PI / 4);
		for (let i = 0; i < 3; i++) {
			const k = 6 + i * 7;
			c.strokeRect(-k, -k, k * 2, k * 2);
		}
		c.beginPath();
		c.arc(0, 0, 4, 0, Math.PI * 2);
		c.fill();
	}
	return tile;
}
function overlayTexture(ctx, w, h, t, shape, radius, kind, color, size, image) {
	ctx.save();
	ctx.beginPath();
	addShapePath(ctx, w, h, 0, shape, radius);
	addShapePath(ctx, w, h, t, shape, radius);
	ctx.clip("evenodd");
	let pattern = null;
	if (image) pattern = ctx.createPattern(image, "repeat");
	else {
		const tile = makeTile(kind, color, size);
		pattern = ctx.createPattern(tile, "repeat");
	}
	if (pattern) {
		ctx.globalAlpha = image ? .72 : .55;
		ctx.globalCompositeOperation = "overlay";
		ctx.fillStyle = pattern;
		ctx.fillRect(0, 0, w, h);
	}
	ctx.restore();
}
function drawBevel(ctx, w, h, t, shape, radius) {
	ctx.save();
	ctx.beginPath();
	addShapePath(ctx, w, h, .8, shape, radius);
	ctx.strokeStyle = "rgba(255,255,255,0.28)";
	ctx.lineWidth = Math.max(1, t * .03);
	ctx.stroke();
	ctx.beginPath();
	addShapePath(ctx, w, h, t * .5, shape, radius);
	ctx.strokeStyle = "rgba(0,0,0,0.18)";
	ctx.lineWidth = Math.max(1, t * .025);
	ctx.stroke();
	ctx.shadowColor = "rgba(0,0,0,0.45)";
	ctx.shadowBlur = Math.max(6, t * .14);
	ctx.beginPath();
	addShapePath(ctx, w, h, t, shape, radius);
	ctx.strokeStyle = "rgba(0,0,0,0.35)";
	ctx.lineWidth = 1.5;
	ctx.stroke();
	ctx.restore();
}
function drawInnerLine(ctx, w, h, t, shape, radius, color) {
	ctx.save();
	ctx.beginPath();
	addShapePath(ctx, w, h, t - 3, shape, radius);
	ctx.strokeStyle = color;
	ctx.globalAlpha = .85;
	ctx.lineWidth = 1.4;
	ctx.stroke();
	ctx.restore();
}
function stampOrnaments(ctx, pts, config) {
	const size = config.decoSize;
	const type = config.decoType;
	const icons = config.icons.length > 0 ? config.icons : ["★"];
	pts.forEach((p, i) => {
		ctx.save();
		ctx.translate(p.x, p.y);
		ctx.rotate(p.angle);
		ctx.fillStyle = config.decoColor;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		if (type === "icons" || type === "both") {
			ctx.font = `600 ${size}px "Segoe UI Symbol", "Noto Sans Symbols", Georgia, serif`;
			ctx.fillText(icons[i % icons.length] ?? "★", 0, type === "both" ? -size * .15 : 0);
		}
		if (type === "text" || type === "both") {
			const txt = config.text.trim() || "•";
			ctx.font = `600 ${Math.max(10, size * .72)}px "Cormorant Garamond", Georgia, serif`;
			const extraY = type === "both" ? size * .7 : 0;
			ctx.fillText(txt, 0, extraY);
		}
		ctx.restore();
	});
}
function stampTextureMotifs(ctx, pts, config, image) {
	const size = config.decoSize;
	const kind = config.texture;
	pts.forEach((p) => {
		ctx.save();
		ctx.translate(p.x, p.y);
		ctx.rotate(p.angle);
		if (image) {
			const s = size * 1.6;
			ctx.drawImage(image, -s / 2, -s / 2, s, s);
			ctx.restore();
			return;
		}
		if (kind === "oro" || kind === "metal") {
			const g = ctx.createLinearGradient(-size, 0, size, 0);
			if (kind === "oro") {
				g.addColorStop(0, "#8B6914");
				g.addColorStop(.35, "#FFD700");
				g.addColorStop(.65, "#FFF8DC");
				g.addColorStop(1, "#8B6914");
			} else {
				g.addColorStop(0, "#555");
				g.addColorStop(.4, "#DDD");
				g.addColorStop(.6, "#FFF");
				g.addColorStop(1, "#555");
			}
			ctx.fillStyle = g;
			ctx.beginPath();
			ctx.ellipse(0, 0, size * .65, size * .28, 0, 0, Math.PI * 2);
			ctx.fill();
		} else if (kind === "barroco") {
			ctx.fillStyle = config.decoColor;
			ctx.beginPath();
			ctx.moveTo(0, -size * .45);
			ctx.quadraticCurveTo(size * .45, -size * .15, size * .35, size * .25);
			ctx.quadraticCurveTo(0, size * .45, -size * .35, size * .25);
			ctx.quadraticCurveTo(-size * .45, -size * .15, 0, -size * .45);
			ctx.fill();
		} else if (kind === "puntos") {
			ctx.fillStyle = config.decoColor;
			ctx.beginPath();
			ctx.arc(0, 0, size * .28, 0, Math.PI * 2);
			ctx.fill();
		} else if (kind === "lineas") {
			ctx.strokeStyle = config.decoColor;
			ctx.lineWidth = 2;
			ctx.beginPath();
			ctx.moveTo(-size * .55, -size * .2);
			ctx.lineTo(size * .55, size * .2);
			ctx.stroke();
		} else if (kind === "cuadros") {
			ctx.fillStyle = config.decoColor;
			ctx.fillRect(-size * .28, -size * .28, size * .56, size * .56);
		} else if (kind === "ondas") {
			ctx.strokeStyle = config.decoColor;
			ctx.lineWidth = 1.8;
			ctx.beginPath();
			ctx.moveTo(-size * .6, 0);
			ctx.quadraticCurveTo(-size * .15, -size * .4, 0, 0);
			ctx.quadraticCurveTo(size * .15, size * .4, size * .6, 0);
			ctx.stroke();
		} else if (kind === "floral") {
			ctx.fillStyle = config.decoColor;
			for (let a = 0; a < 5; a++) {
				ctx.beginPath();
				ctx.ellipse(0, -size * .22, size * .15, size * .28, a * 72 * Math.PI / 180, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.beginPath();
			ctx.arc(0, 0, size * .12, 0, Math.PI * 2);
			ctx.fill();
		} else if (kind === "madera") {
			ctx.fillStyle = config.decoColor;
			ctx.fillRect(-size * .7, -size * .18, size * 1.4, size * .36);
		} else if (kind === "damasco") {
			ctx.fillStyle = config.decoColor;
			ctx.beginPath();
			ctx.moveTo(0, -size * .4);
			ctx.lineTo(size * .28, 0);
			ctx.lineTo(0, size * .4);
			ctx.lineTo(-size * .28, 0);
			ctx.closePath();
			ctx.fill();
		}
		ctx.restore();
	});
}
function drawFrame(ctx, config, extras = {}) {
	const w = config.width;
	const h = config.height;
	const t = clamp(config.thickness, 12, maxThickness(w, h));
	const shape = config.shape;
	const radius = config.cornerRadius;
	const ratios = normalizedRatios(config.ratios);
	ctx.clearRect(0, 0, w, h);
	if (extras.includePhoto && extras.photo) coverImage(ctx, extras.photo, w, h);
	const g0 = t * ratios[0];
	const g1 = t * ratios[1];
	const g2 = t * ratios[2];
	fillBand(ctx, w, h, 0, g0, config.bands[0], shape, radius);
	fillBand(ctx, w, h, g0, g0 + g1, config.bands[1], shape, radius);
	fillBand(ctx, w, h, g0 + g1, g0 + g1 + g2, config.bands[2], shape, radius);
	if (config.decoType === "texture") overlayTexture(ctx, w, h, t, shape, radius, config.texture, config.decoColor, config.decoSize);
	else if (config.decoType === "image" && extras.textureImg) overlayTexture(ctx, w, h, t, shape, radius, config.texture, config.decoColor, config.decoSize, extras.textureImg);
	if (config.bevel) drawBevel(ctx, w, h, t, shape, radius);
	if (config.innerLine) drawInnerLine(ctx, w, h, t, shape, radius, config.decoColor);
	if (config.decoType === "none") return;
	const pts = contourPoints(w, h, g0 + g1 * .5, config.decoCount, shape, radius);
	if (config.decoType === "texture" || config.decoType === "image") {
		stampTextureMotifs(ctx, pts, config, config.decoType === "image" ? extras.textureImg : null);
		return;
	}
	stampOrnaments(ctx, pts, config);
}
function renderToCanvas(config, extras = {}) {
	const canvas = document.createElement("canvas");
	canvas.width = config.width;
	canvas.height = config.height;
	const ctx = canvas.getContext("2d");
	if (ctx) drawFrame(ctx, config, extras);
	return canvas;
}
async function canvasPngBlob(canvas) {
	const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
	if (!blob) throw new Error("No se pudo generar el PNG");
	return blob;
}
function safeFileName(name) {
	const trimmed = name.trim() || "marco.png";
	return trimmed.toLowerCase().endsWith(".png") ? trimmed : `${trimmed}.png`;
}
async function downloadPng(config, extras, fileName, directoryHandle) {
	const blob = await canvasPngBlob(renderToCanvas(config, extras));
	const name = safeFileName(fileName);
	if (directoryHandle) {
		const writable = await (await directoryHandle.getFileHandle(name, { create: true })).createWritable();
		await writable.write(blob);
		await writable.close();
		return {
			method: "folder",
			name
		};
	}
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
	return {
		method: "download",
		name
	};
}
async function copyPng(config, extras) {
	const blob = await canvasPngBlob(renderToCanvas(config, extras));
	await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
}
async function pickDirectory() {
	if (!("showDirectoryPicker" in window) || typeof window.showDirectoryPicker !== "function") throw new Error("unsupported");
	return window.showDirectoryPicker();
}
function useLoadedImage(url) {
	const [image, setImage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!url) {
			setImage(null);
			return;
		}
		let cancelled = false;
		const img = new Image();
		img.onload = () => {
			if (!cancelled) setImage(img);
		};
		img.onerror = () => {
			if (!cancelled) setImage(null);
		};
		img.src = url;
		return () => {
			cancelled = true;
		};
	}, [url]);
	return image;
}
var MAX_SIZE = 3e3;
var DEFAULT_CONFIG = {
	width: 900,
	height: 650,
	shape: "rounded",
	thickness: 64,
	cornerRadius: 28,
	bands: [
		"#c9a227",
		"#6b1220",
		"#161410"
	],
	ratios: [
		.5,
		.25,
		.25
	],
	decoType: "none",
	icons: ["★"],
	text: "kmell",
	texture: "oro",
	decoColor: "#f0d78c",
	decoSize: 22,
	decoCount: 20,
	bevel: true,
	innerLine: true
};
var ORNAMENTS = [
	"★",
	"♥",
	"✦",
	"◆",
	"●",
	"▲",
	"✿",
	"⚜",
	"⚔",
	"☘",
	"☀",
	"☾",
	"❖",
	"♛",
	"♚",
	"♦",
	"♣",
	"♠",
	"✧",
	"✪",
	"✯",
	"❀",
	"❁",
	"❂",
	"⚡",
	"❄",
	"☽",
	"✈",
	"✎",
	"♪",
	"♫",
	"☁",
	"☂",
	"☃",
	"♔",
	"♕"
];
var PALETTE = [
	"#c9a227",
	"#ffd700",
	"#b8860b",
	"#daa520",
	"#f0e68c",
	"#ffec8b",
	"#cd853f",
	"#d2691e",
	"#8b4513",
	"#a0522d",
	"#deb887",
	"#f4a460",
	"#c0c0c0",
	"#a8a8a8",
	"#708090",
	"#2f4f4f",
	"#1c1c1c",
	"#696969",
	"#8b0000",
	"#a52a2a",
	"#dc143c",
	"#ff4500",
	"#ff6347",
	"#b22222",
	"#006400",
	"#228b22",
	"#2e8b57",
	"#3cb371",
	"#20b2aa",
	"#008080",
	"#000080",
	"#191970",
	"#4169e1",
	"#1e90ff",
	"#00bfff",
	"#4682b4",
	"#4b0082",
	"#8a2be2",
	"#9932cc",
	"#ba55d3",
	"#ffffff",
	"#f5f5f5",
	"#dcdcdc",
	"#d3d3d3",
	"#a9a9a9",
	"#808080",
	"#f3e6c8",
	"#3e2723"
];
var ASPECT_PRESETS = [
	{
		id: "libre",
		label: "Libre",
		ratio: "9∶6.5",
		width: 900,
		height: 650
	},
	{
		id: "cuadrado",
		label: "Cuadrado",
		ratio: "1∶1",
		width: 1080,
		height: 1080
	},
	{
		id: "retrato",
		label: "Retrato",
		ratio: "4∶5",
		width: 1080,
		height: 1350
	},
	{
		id: "historia",
		label: "Historia",
		ratio: "9∶16",
		width: 1080,
		height: 1920
	},
	{
		id: "clasico",
		label: "Clásico",
		ratio: "4∶3",
		width: 1200,
		height: 900
	},
	{
		id: "paisaje",
		label: "Paisaje",
		ratio: "16∶9",
		width: 1920,
		height: 1080
	},
	{
		id: "foto",
		label: "Foto",
		ratio: "3∶2",
		width: 1500,
		height: 1e3
	}
];
var FRAME_PRESETS = [
	{
		id: "imperial",
		name: "Imperial",
		hint: "Oro y carmín",
		config: {
			shape: "rounded",
			thickness: 64,
			cornerRadius: 28,
			bands: [
				"#c9a227",
				"#6b1220",
				"#161410"
			],
			ratios: [
				.5,
				.25,
				.25
			],
			decoType: "icons",
			icons: ["★", "✦"],
			decoColor: "#f0d78c",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "plata",
		name: "Plata",
		hint: "Estaño bruñido",
		config: {
			shape: "rounded",
			thickness: 56,
			cornerRadius: 20,
			bands: [
				"#c5c8cc",
				"#6a737b",
				"#1a1c1e"
			],
			ratios: [
				.45,
				.3,
				.25
			],
			decoType: "texture",
			texture: "metal",
			decoColor: "#e8eaed",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "nogal",
		name: "Nogal",
		hint: "Madera oscura",
		config: {
			shape: "rect",
			thickness: 72,
			cornerRadius: 0,
			bands: [
				"#8b5a2b",
				"#3e2723",
				"#1a120c"
			],
			ratios: [
				.55,
				.25,
				.2
			],
			decoType: "texture",
			texture: "madera",
			decoColor: "#c4a574",
			bevel: true,
			innerLine: false
		}
	},
	{
		id: "marino",
		name: "Marino",
		hint: "Armada y marfil",
		config: {
			shape: "arch",
			thickness: 60,
			cornerRadius: 16,
			bands: [
				"#1e3a5f",
				"#c9a86c",
				"#0b1320"
			],
			ratios: [
				.5,
				.22,
				.28
			],
			decoType: "icons",
			icons: ["⚜", "◆"],
			decoColor: "#e6d5a8",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "olivo",
		name: "Olivo",
		hint: "Bosque sereno",
		config: {
			shape: "rounded",
			thickness: 58,
			cornerRadius: 36,
			bands: [
				"#6b7c3a",
				"#3d4a24",
				"#1a1c14"
			],
			ratios: [
				.48,
				.28,
				.24
			],
			decoType: "icons",
			icons: ["☘", "✿"],
			decoColor: "#d5e0b0",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "marfil",
		name: "Marfil",
		hint: "Lino y nogal",
		config: {
			shape: "rounded",
			thickness: 52,
			cornerRadius: 18,
			bands: [
				"#f3e6c8",
				"#b89b72",
				"#3f3328"
			],
			ratios: [
				.5,
				.28,
				.22
			],
			decoType: "text",
			text: "atelier",
			decoColor: "#5c4636",
			decoSize: 16,
			decoCount: 12,
			bevel: true,
			innerLine: false
		}
	},
	{
		id: "carbon",
		name: "Carbón",
		hint: "Grafito mate",
		config: {
			shape: "rect",
			thickness: 48,
			cornerRadius: 0,
			bands: [
				"#3a3a3a",
				"#161616",
				"#0a0a0a"
			],
			ratios: [
				.4,
				.35,
				.25
			],
			decoType: "none",
			decoColor: "#c0c0c0",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "carmesi",
		name: "Carmesí",
		hint: "Teatro antiguo",
		config: {
			shape: "oval",
			thickness: 70,
			cornerRadius: 40,
			bands: [
				"#8b1e3f",
				"#c9a227",
				"#1a0a10"
			],
			ratios: [
				.52,
				.2,
				.28
			],
			decoType: "icons",
			icons: ["♥", "❀"],
			decoColor: "#f0d78c",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "artico",
		name: "Ártico",
		hint: "Hielo y pizarra",
		config: {
			shape: "circle",
			thickness: 54,
			cornerRadius: 0,
			bands: [
				"#d9e2ea",
				"#7a8b99",
				"#1b242c"
			],
			ratios: [
				.46,
				.3,
				.24
			],
			decoType: "texture",
			texture: "puntos",
			decoColor: "#eef3f7",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "ocaso",
		name: "Ocaso",
		hint: "Terracota",
		config: {
			shape: "rounded",
			thickness: 62,
			cornerRadius: 22,
			bands: [
				"#c45c26",
				"#5c1a1a",
				"#1a0e08"
			],
			ratios: [
				.5,
				.25,
				.25
			],
			decoType: "texture",
			texture: "ondas",
			decoColor: "#f0c48c",
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "barroco",
		name: "Barroco",
		hint: "Ornamento rico",
		config: {
			shape: "rounded",
			thickness: 80,
			cornerRadius: 32,
			bands: [
				"#b8860b",
				"#4a0e16",
				"#120e0a"
			],
			ratios: [
				.42,
				.33,
				.25
			],
			decoType: "texture",
			texture: "barroco",
			decoColor: "#ffe9a8",
			decoSize: 28,
			decoCount: 24,
			bevel: true,
			innerLine: true
		}
	},
	{
		id: "floral",
		name: "Floral",
		hint: "Jardín íntimo",
		config: {
			shape: "arch",
			thickness: 60,
			cornerRadius: 24,
			bands: [
				"#5c4033",
				"#d4a5a5",
				"#2a1810"
			],
			ratios: [
				.5,
				.22,
				.28
			],
			decoType: "icons",
			icons: [
				"✿",
				"❀",
				"❁"
			],
			decoColor: "#f3d6d6",
			decoSize: 20,
			decoCount: 22,
			bevel: true,
			innerLine: true
		}
	}
];
function applyPreset(base, preset) {
	return {
		...base,
		...preset.config,
		bands: preset.config.bands ?? base.bands
	};
}
var KEY = "marco_atelier_v1";
function isConfig(v) {
	if (!v || typeof v !== "object") return false;
	const c = v;
	return typeof c.width === "number" && typeof c.height === "number" && Array.isArray(c.bands);
}
function loadPersisted() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {
			config: DEFAULT_CONFIG,
			saved: [],
			fileName: "marco.png",
			includePhoto: false
		};
		const parsed = JSON.parse(raw);
		return {
			config: isConfig(parsed.config) ? {
				...DEFAULT_CONFIG,
				...parsed.config
			} : DEFAULT_CONFIG,
			saved: Array.isArray(parsed.saved) ? parsed.saved : [],
			fileName: typeof parsed.fileName === "string" ? parsed.fileName : "marco.png",
			includePhoto: Boolean(parsed.includePhoto)
		};
	} catch {
		return {
			config: DEFAULT_CONFIG,
			saved: [],
			fileName: "marco.png",
			includePhoto: false
		};
	}
}
function savePersisted(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
}
function persistNow(state) {
	savePersisted({
		config: state.config,
		saved: state.saved,
		fileName: state.fileName,
		includePhoto: state.includePhoto
	});
}
var useFrameStore = create((set, get) => ({
	config: DEFAULT_CONFIG,
	saved: [],
	fileName: "marco.png",
	includePhoto: false,
	photoUrl: null,
	textureUrl: null,
	activeBand: 0,
	hydrated: false,
	hydrate: () => {
		if (get().hydrated || typeof window === "undefined") return;
		set({
			...loadPersisted(),
			hydrated: true
		});
	},
	patch: (partial) => {
		set((s) => {
			const next = {
				...s,
				config: {
					...s.config,
					...partial
				}
			};
			persistNow(next);
			return next;
		});
	},
	setBand: (index, color) => {
		set((s) => {
			const bands = [...s.config.bands];
			bands[index] = color;
			const next = {
				...s,
				config: {
					...s.config,
					bands
				}
			};
			persistNow(next);
			return next;
		});
	},
	setRatio: (index, value) => {
		set((s) => {
			const ratios = [...s.config.ratios];
			ratios[index] = Math.max(.08, value);
			const sum = ratios[0] + ratios[1] + ratios[2];
			const normalized = [
				ratios[0] / sum,
				ratios[1] / sum,
				ratios[2] / sum
			];
			const next = {
				...s,
				config: {
					...s.config,
					ratios: normalized
				}
			};
			persistNow(next);
			return next;
		});
	},
	toggleIcon: (icon) => {
		set((s) => {
			const icons = s.config.icons.includes(icon) ? s.config.icons.filter((i) => i !== icon) : [...s.config.icons, icon];
			const next = {
				...s,
				config: {
					...s.config,
					icons
				}
			};
			persistNow(next);
			return next;
		});
	},
	applyPreset: (preset) => {
		set((s) => {
			const next = {
				...s,
				config: applyPreset(s.config, preset)
			};
			persistNow(next);
			return next;
		});
	},
	setShape: (shape) => get().patch({ shape }),
	setDecoType: (decoType) => get().patch({ decoType }),
	setTexture: (texture) => get().patch({ texture }),
	setPhotoUrl: (url) => {
		const prev = get().photoUrl;
		if (prev && prev !== url) URL.revokeObjectURL(prev);
		set({ photoUrl: url });
	},
	setTextureUrl: (url) => {
		const prev = get().textureUrl;
		if (prev && prev !== url) URL.revokeObjectURL(prev);
		set({ textureUrl: url });
		if (url) get().patch({ decoType: "image" });
	},
	setFileName: (fileName) => {
		set((s) => {
			const next = {
				...s,
				fileName
			};
			persistNow(next);
			return next;
		});
	},
	setIncludePhoto: (includePhoto) => {
		set((s) => {
			const next = {
				...s,
				includePhoto
			};
			persistNow(next);
			return next;
		});
	},
	setActiveBand: (activeBand) => set({ activeBand }),
	saveStyle: (name) => {
		set((s) => {
			const style = {
				id: crypto.randomUUID(),
				name: name.trim() || "Estilo",
				createdAt: Date.now(),
				config: { ...s.config }
			};
			const next = {
				...s,
				saved: [style, ...s.saved].slice(0, 24)
			};
			persistNow(next);
			return next;
		});
	},
	loadStyle: (id) => {
		const found = get().saved.find((x) => x.id === id);
		if (found) get().patch(found.config);
	},
	deleteStyle: (id) => {
		set((s) => {
			const next = {
				...s,
				saved: s.saved.filter((x) => x.id !== id)
			};
			persistNow(next);
			return next;
		});
	},
	clearDecor: () => {
		get().setTextureUrl(null);
		get().patch({
			decoType: "none",
			icons: []
		});
	},
	resetAll: () => {
		get().setPhotoUrl(null);
		get().setTextureUrl(null);
		set((s) => {
			const next = {
				...s,
				config: DEFAULT_CONFIG,
				includePhoto: false,
				activeBand: 0
			};
			persistNow(next);
			return next;
		});
	}
}));
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-xs font-medium text-muted-foreground", className),
	...props
}));
Label.displayName = Root.displayName;
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-11 w-full items-center justify-between gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground shadow-[var(--shadow-border)] focus:outline-none focus:ring-2 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 opacity-60" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-72 min-w-32 overflow-hidden rounded-lg border border-border bg-popover text-popover-foreground shadow-[var(--shadow-border)]", position === "popper" && "data-[side=bottom]:translate-y-1", className),
	position,
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
		className: cn("p-1", position === "popper" && "w-full min-w-[var(--radix-select-trigger-width)]"),
		children
	})
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-pointer select-none items-center rounded-sm py-2 pr-8 pl-2 text-sm outline-none focus:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex size-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root$1.displayName;
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] ring-2 ring-background transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" })]
}));
Slider.displayName = Slider$1.displayName;
function Thumb({ presetId }) {
	const ref = (0, import_react.useRef)(null);
	const preset = FRAME_PRESETS.find((p) => p.id === presetId);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas || !preset) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const w = 120;
		const h = 88;
		canvas.width = 240;
		canvas.height = 176;
		ctx.scale(2, 2);
		const config = applyPreset(DEFAULT_CONFIG, preset);
		drawFrame(ctx, {
			...config,
			width: w,
			height: h,
			thickness: 16,
			decoSize: 7,
			decoCount: 10,
			cornerRadius: Math.min(12, config.cornerRadius)
		});
	}, [preset]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "h-[66px] w-[90px]"
	});
}
function PresetStrip() {
	const apply = useFrameStore((s) => s.applyPreset);
	const current = useFrameStore((s) => s.config);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-2 overflow-x-auto pb-1",
		children: FRAME_PRESETS.map((preset) => {
			const active = current.bands[0] === preset.config.bands?.[0] && current.shape === (preset.config.shape ?? current.shape);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => apply(preset),
				className: cn("flex shrink-0 flex-col gap-1.5 rounded-lg p-1.5 text-left transition-colors duration-[var(--motion-quick)] ease-[var(--ease-out)]", active ? "bg-accent" : "hover:bg-accent/60"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "overflow-hidden rounded-md bg-checker shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { presetId: preset.id })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "px-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs font-medium text-foreground",
						children: preset.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[10px] text-muted-foreground",
						children: preset.hint
					})]
				})]
			}, preset.id);
		})
	});
}
var SHAPES = [
	{
		id: "rect",
		label: "Rectángulo"
	},
	{
		id: "rounded",
		label: "Redondeado"
	},
	{
		id: "circle",
		label: "Círculo"
	},
	{
		id: "oval",
		label: "Óvalo"
	},
	{
		id: "arch",
		label: "Arco"
	}
];
var DECO_TYPES = [
	{
		id: "none",
		label: "Ninguno"
	},
	{
		id: "icons",
		label: "Motivos"
	},
	{
		id: "text",
		label: "Texto"
	},
	{
		id: "both",
		label: "Motivos y texto"
	},
	{
		id: "texture",
		label: "Textura"
	},
	{
		id: "image",
		label: "Imagen propia"
	}
];
var TEXTURES = [
	{
		id: "oro",
		label: "Hoja de oro"
	},
	{
		id: "metal",
		label: "Metal"
	},
	{
		id: "barroco",
		label: "Barroco"
	},
	{
		id: "puntos",
		label: "Puntos"
	},
	{
		id: "lineas",
		label: "Líneas"
	},
	{
		id: "cuadros",
		label: "Cuadros"
	},
	{
		id: "ondas",
		label: "Ondas"
	},
	{
		id: "floral",
		label: "Floral"
	},
	{
		id: "madera",
		label: "Madera"
	},
	{
		id: "damasco",
		label: "Damasco"
	}
];
var BAND_LABELS = [
	"Exterior",
	"Media",
	"Interior"
];
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-base font-medium tracking-tight text-foreground",
			children: title
		}), children]
	});
}
function Row({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2",
		children
	});
}
function Field({ label, value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-sans text-[11px] tabular-nums text-muted-foreground",
				children: value
			}) : null]
		}), children]
	});
}
function Controls() {
	const config = useFrameStore((s) => s.config);
	const patch = useFrameStore((s) => s.patch);
	const setBand = useFrameStore((s) => s.setBand);
	const setRatio = useFrameStore((s) => s.setRatio);
	const toggleIcon = useFrameStore((s) => s.toggleIcon);
	const setDecoType = useFrameStore((s) => s.setDecoType);
	const setTexture = useFrameStore((s) => s.setTexture);
	const setShape = useFrameStore((s) => s.setShape);
	const activeBand = useFrameStore((s) => s.activeBand);
	const setActiveBand = useFrameStore((s) => s.setActiveBand);
	const setPhotoUrl = useFrameStore((s) => s.setPhotoUrl);
	const setTextureUrl = useFrameStore((s) => s.setTextureUrl);
	const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
	const includePhoto = useFrameStore((s) => s.includePhoto);
	const photoUrl = useFrameStore((s) => s.photoUrl);
	const fileName = useFrameStore((s) => s.fileName);
	const setFileName = useFrameStore((s) => s.setFileName);
	const clearDecor = useFrameStore((s) => s.clearDecor);
	const resetAll = useFrameStore((s) => s.resetAll);
	const photoInput = (0, import_react.useRef)(null);
	const textureInput = (0, import_react.useRef)(null);
	const showIcons = config.decoType === "icons" || config.decoType === "both";
	const showText = config.decoType === "text" || config.decoType === "both";
	const showTexture = config.decoType === "texture";
	const showImage = config.decoType === "image";
	const showDecoStyle = config.decoType !== "none";
	function onPhoto(files) {
		const file = files?.[0];
		if (!file) return;
		setPhotoUrl(URL.createObjectURL(file));
		setIncludePhoto(true);
	}
	function onTextureFile(files) {
		const file = files?.[0];
		if (!file) return;
		setTextureUrl(URL.createObjectURL(file));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Estilos",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetStrip, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Tamaño y forma",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1.5 overflow-x-auto pb-0.5",
						children: ASPECT_PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => patch({
								width: p.width,
								height: p.height
							}),
							className: cn("h-11 shrink-0 rounded-md px-3 text-xs font-medium transition-colors duration-[var(--motion-quick)]", config.width === p.width && config.height === p.height ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-accent"),
							children: [p.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1.5 text-[10px] opacity-70",
								children: p.ratio
							})]
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ancho",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 300,
							max: MAX_SIZE,
							value: config.width,
							onChange: (e) => patch({ width: Math.min(MAX_SIZE, Math.max(300, Number(e.target.value) || 300)) })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Alto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 300,
							max: MAX_SIZE,
							value: config.height,
							onChange: (e) => patch({ height: Math.min(MAX_SIZE, Math.max(300, Number(e.target.value) || 300)) })
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-1.5",
						children: SHAPES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setShape(s.id),
							className: cn("flex h-14 flex-col items-center justify-center gap-1 rounded-md px-1 text-center text-xs font-medium leading-tight transition-colors duration-[var(--motion-quick)]", config.shape === s.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-accent hover:text-foreground"),
							children: [s.id === "circle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-4" }) : s.id === "rect" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RectangleHorizontal, { className: "size-4" }), s.label]
						}, s.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Grosor",
						value: `${config.thickness} px`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 25,
							max: 160,
							step: 1,
							value: [config.thickness],
							onValueChange: (v) => patch({ thickness: v[0] ?? config.thickness })
						})
					}),
					config.shape === "rounded" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Esquinas",
						value: `${config.cornerRadius} px`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 4,
							max: 120,
							step: 1,
							value: [config.cornerRadius],
							onValueChange: (v) => patch({ cornerRadius: v[0] ?? config.cornerRadius })
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Bandas",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Tres capas: exterior, media e interior. Pulsa una para pintar con la paleta."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 overflow-hidden rounded-md shadow-[var(--shadow-border)]",
						children: config.bands.map((color, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setActiveBand(i),
							style: {
								width: `${config.ratios[i] * 100}%`,
								background: color
							},
							className: cn("relative h-full min-w-8 transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]", activeBand === i && "ring-2 ring-ring ring-inset"),
							"aria-label": BAND_LABELS[i]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: config.bands.map((color, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: BAND_LABELS[i],
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("block h-11 w-full rounded-md shadow-[var(--shadow-border)]", activeBand === i && "ring-2 ring-ring"),
									style: { background: color }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									value: color,
									onChange: (e) => {
										setActiveBand(i);
										setBand(i, e.target.value);
									},
									onClick: () => setActiveBand(i),
									className: "absolute inset-0 cursor-pointer opacity-0",
									"aria-label": `Color ${BAND_LABELS[i]}`
								})]
							})
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Proporción ${BAND_LABELS[activeBand].toLowerCase()}`,
						value: `${Math.round(config.ratios[activeBand] * 100)}%`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: .1,
							max: .7,
							step: .01,
							value: [config.ratios[activeBand]],
							onValueChange: (v) => setRatio(activeBand, v[0] ?? config.ratios[activeBand])
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Paleta"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-8 gap-1",
						children: PALETTE.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setBand(activeBand, col),
							className: cn("aspect-square rounded-sm shadow-[var(--shadow-border)]", config.bands[activeBand].toLowerCase() === col && "ring-2 ring-ring"),
							style: { background: col },
							"aria-label": col
						}, col))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-foreground",
								children: "Relieve"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: config.bevel,
								onCheckedChange: (v) => patch({ bevel: v })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-foreground",
								children: "Filete interior"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: config.innerLine,
								onCheckedChange: (v) => patch({ innerLine: v })
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Adornos",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: config.decoType,
							onValueChange: (v) => setDecoType(v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DECO_TYPES.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d.id,
								children: d.label
							}, d.id)) })]
						})
					}),
					showIcons && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Motivos (varios a la vez)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid max-h-32 grid-cols-8 gap-1 overflow-y-auto pr-1",
						children: ORNAMENTS.map((ico) => {
							const on = config.icons.includes(ico);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleIcon(ico),
								className: cn("flex size-9 items-center justify-center rounded-sm text-base transition-colors duration-[var(--motion-quick)]", on ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-accent"),
								"aria-pressed": on,
								"aria-label": `Motivo ${ico}`,
								children: ico
							}, ico);
						})
					})] }),
					showText && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Texto en el contorno",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							maxLength: 18,
							value: config.text,
							onChange: (e) => patch({ text: e.target.value }),
							placeholder: "tu texto"
						})
					}),
					showTexture && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Plantilla",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: config.texture,
							onValueChange: (v) => setTexture(v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: TEXTURES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: t.id,
								children: t.label
							}, t.id)) })]
						})
					}),
					showImage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: textureInput,
							type: "file",
							accept: "image/*",
							className: "sr-only",
							tabIndex: -1,
							"aria-hidden": true,
							onChange: (e) => onTextureFile(e.target.files)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => textureInput.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Subir textura"]
						})]
					}),
					showDecoStyle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Color",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block h-11 w-full rounded-md shadow-[var(--shadow-border)]",
								style: { background: config.decoColor }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: config.decoColor,
								onChange: (e) => patch({ decoColor: e.target.value }),
								className: "absolute inset-0 cursor-pointer opacity-0"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tamaño",
						value: `${config.decoSize}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 10,
							max: 52,
							step: 1,
							value: [config.decoSize],
							onValueChange: (v) => patch({ decoSize: v[0] ?? config.decoSize })
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cantidad en el contorno",
						value: `${config.decoCount}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 6,
							max: 64,
							step: 1,
							value: [config.decoCount],
							onValueChange: (v) => patch({ decoCount: v[0] ?? config.decoCount })
						})
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Foto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: photoInput,
						type: "file",
						accept: "image/*",
						className: "sr-only",
						tabIndex: -1,
						"aria-hidden": true,
						onChange: (e) => onPhoto(e.target.files)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => photoInput.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), photoUrl ? "Cambiar foto" : "Colocar foto"]
					}),
					photoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-foreground",
							children: "Ver foto en el hueco"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: includePhoto,
							onCheckedChange: setIncludePhoto
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "El PNG por defecto deja el centro transparente. Activa “incluir foto” al exportar si quieres el retrato dentro."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Archivo",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nombre del PNG",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: fileName,
						onChange: (e) => setFileName(e.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: clearDecor,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Limpiar adornos"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: resetAll,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Restablecer"]
					})]
				})]
			})
		]
	});
}
function FramePreview() {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const config = useFrameStore((s) => s.config);
	const photoUrl = useFrameStore((s) => s.photoUrl);
	const textureUrl = useFrameStore((s) => s.textureUrl);
	const includePhoto = useFrameStore((s) => s.includePhoto);
	const setPhotoUrl = useFrameStore((s) => s.setPhotoUrl);
	const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
	const photo = useLoadedImage(photoUrl);
	const texture = useLoadedImage(textureUrl);
	const redraw = (0, import_react.useCallback)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const maxW = Math.max(80, wrap.clientWidth - 20);
		const maxH = Math.max(80, wrap.clientHeight - 20);
		const scale = Math.min(1, maxW / config.width, maxH / config.height);
		const dw = Math.max(1, Math.round(config.width * scale));
		const dh = Math.max(1, Math.round(config.height * scale));
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		canvas.width = Math.round(dw * dpr);
		canvas.height = Math.round(dh * dpr);
		canvas.style.width = `${dw}px`;
		canvas.style.height = `${dh}px`;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.scale(dw / config.width, dh / config.height);
		drawFrame(ctx, config, {
			photo,
			textureImg: texture,
			includePhoto: includePhoto && Boolean(photo)
		});
	}, [
		config,
		photo,
		texture,
		includePhoto
	]);
	(0, import_react.useEffect)(() => {
		redraw();
	}, [redraw]);
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		if (!wrap) return;
		const ro = new ResizeObserver(() => redraw());
		ro.observe(wrap);
		return () => ro.disconnect();
	}, [redraw]);
	function onDrop(e) {
		e.preventDefault();
		const file = e.dataTransfer.files[0];
		if (!file || !file.type.startsWith("image/")) return;
		const url = URL.createObjectURL(file);
		setPhotoUrl(url);
		setIncludePhoto(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		onDragOver: (e) => e.preventDefault(),
		onDrop,
		className: cn("bg-checker relative flex min-h-52 flex-1 items-center justify-center overflow-hidden rounded-lg", "min-h-[220px] md:min-h-[420px]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "max-h-full max-w-full shadow-[0_12px_40px_rgb(0_0_0_/0.45)]",
			"aria-label": "Vista previa del marco"
		}), !photoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "pointer-events-none absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-background/80 px-3 py-1 text-[11px] text-muted-foreground backdrop-blur-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-3" }), "Suelta una foto para probar el marco"]
		})]
	});
}
function Studio() {
	const hydrate = useFrameStore((s) => s.hydrate);
	const config = useFrameStore((s) => s.config);
	const fileName = useFrameStore((s) => s.fileName);
	const includePhoto = useFrameStore((s) => s.includePhoto);
	const setIncludePhoto = useFrameStore((s) => s.setIncludePhoto);
	const photoUrl = useFrameStore((s) => s.photoUrl);
	const textureUrl = useFrameStore((s) => s.textureUrl);
	const saved = useFrameStore((s) => s.saved);
	const saveStyle = useFrameStore((s) => s.saveStyle);
	const loadStyle = useFrameStore((s) => s.loadStyle);
	const deleteStyle = useFrameStore((s) => s.deleteStyle);
	const photo = useLoadedImage(photoUrl);
	const texture = useLoadedImage(textureUrl);
	const dirRef = (0, import_react.useRef)(null);
	const [styleName, setStyleName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const extras = {
		photo,
		textureImg: texture,
		includePhoto: includePhoto && Boolean(photo)
	};
	async function onDownload() {
		setBusy(true);
		try {
			const result = await downloadPng(config, extras, fileName, dirRef.current);
			toast.success(result.method === "folder" ? `Guardado en la carpeta: ${result.name}` : `Descargado: ${result.name}`);
		} catch (err) {
			console.error(err);
			toast.error("No se pudo guardar el PNG");
		} finally {
			setBusy(false);
		}
	}
	async function onCopy() {
		try {
			await copyPng(config, extras);
			toast.success("PNG copiado al portapapeles");
		} catch {
			toast.error("Este navegador no permite copiar la imagen");
		}
	}
	async function onFolder() {
		try {
			dirRef.current = await pickDirectory();
			toast.success("Carpeta lista. El PNG se guardará ahí.");
		} catch (err) {
			if (err instanceof Error && err.message === "unsupported") {
				toast.error("Elegir carpeta solo funciona en Chrome o Edge");
				return;
			}
		}
	}
	function onSaveStyle() {
		saveStyle(styleName);
		setStyleName("");
		toast.success("Estilo guardado en este dispositivo");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border px-4 py-3 md:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-[1200px] items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 items-center justify-center rounded-lg bg-secondary text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-medium tracking-[0.18em] text-muted-foreground uppercase",
								children: "Atelier"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-xl leading-tight font-semibold tracking-tight md:text-2xl",
								children: "Creador de Marcos"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: onFolder,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }), "Carpeta"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								size: "sm",
								onClick: onCopy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copiar"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: onDownload,
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Guardar PNG"]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-[1200px] flex-1 flex-col gap-4 p-4 md:grid md:grid-cols-[360px_minmax(0,1fr)] md:gap-6 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "order-2 min-h-0 pb-24 md:order-1 md:h-[calc(100dvh-8.5rem)] md:overflow-y-auto md:pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Controls, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-base font-medium tracking-tight",
									children: "Estilos guardados"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Nombre del estilo",
										value: styleName,
										onChange: (e) => setStyleName(e.target.value),
										onKeyDown: (e) => {
											if (e.key === "Enter") onSaveStyle();
										}
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "secondary",
										onClick: onSaveStyle,
										className: "shrink-0 px-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Guardar"]
									})]
								}),
								saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Los estilos quedan en este dispositivo. No se envían a ningún servidor."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "flex flex-col gap-1",
									children: saved.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-2 rounded-md bg-secondary px-2 py-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => loadStyle(s.id),
											className: "min-w-0 flex-1 truncate text-left text-sm hover:text-primary",
											children: s.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => deleteStyle(s.id),
											className: "flex size-9 items-center justify-center rounded-sm text-muted-foreground hover:bg-accent hover:text-foreground",
											"aria-label": `Eliminar ${s.name}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
										})]
									}, s.id))
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 pt-4 pb-20 text-xs leading-relaxed text-muted-foreground md:pb-4",
						children: "Centro transparente por defecto. Inspirado en el original de kmell@hotmail.com."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "order-1 flex min-h-0 flex-col gap-3 md:order-2 md:sticky md:top-6 md:h-[calc(100dvh-8.5rem)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex min-h-0 flex-1 flex-col rounded-2xl bg-card p-3 shadow-[var(--shadow-border)] md:p-4"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between gap-3 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-base font-medium tracking-tight",
									children: "Vista previa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] tabular-nums text-muted-foreground",
									children: [
										config.width,
										" × ",
										config.height
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FramePreview, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center justify-between gap-2 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex h-11 items-center gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: includePhoto,
										onCheckedChange: setIncludePhoto,
										disabled: !photoUrl
									}), "Incluir foto en el PNG"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-muted-foreground",
									children: "Hueco transparente si está apagado"
								})]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 p-3 backdrop-blur-sm md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "flex-1",
						onClick: onCopy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copiar"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "flex-[2]",
						onClick: onDownload,
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Guardar PNG"]
					})]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
